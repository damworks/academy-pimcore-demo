-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `filename` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
  `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `mimetype` varchar(190) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `dataModificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  `customSettings` longtext DEFAULT NULL,
  `hasMetaData` tinyint(1) NOT NULL DEFAULT 0,
  `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fullpath` (`path`,`filename`),
  KEY `parentId` (`parentId`),
  KEY `filename` (`filename`),
  KEY `modificationDate` (`modificationDate`),
  KEY `versionCount` (`versionCount`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES
(1,0,'folder','','/',NULL,1759936097,1759936097,NULL,1,1,NULL,0,0);
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_image_thumbnail_cache`
--

DROP TABLE IF EXISTS `assets_image_thumbnail_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_image_thumbnail_cache` (
  `cid` int(11) unsigned NOT NULL,
  `name` varchar(190) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `filename` varchar(190) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `filesize` int(11) unsigned DEFAULT NULL,
  `width` smallint(5) unsigned DEFAULT NULL,
  `height` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`cid`,`name`,`filename`),
  CONSTRAINT `FK_assets_image_thumbnail_cache_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_image_thumbnail_cache`
--

LOCK TABLES `assets_image_thumbnail_cache` WRITE;
/*!40000 ALTER TABLE `assets_image_thumbnail_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_image_thumbnail_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_metadata`
--

DROP TABLE IF EXISTS `assets_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_metadata` (
  `cid` int(11) unsigned NOT NULL,
  `name` varchar(190) NOT NULL,
  `language` varchar(10) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL DEFAULT '',
  `type` enum('input','textarea','asset','document','object','date','select','checkbox') DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  PRIMARY KEY (`cid`,`name`,`language`),
  KEY `name` (`name`),
  CONSTRAINT `FK_assets_metadata_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_metadata`
--

LOCK TABLES `assets_metadata` WRITE;
/*!40000 ALTER TABLE `assets_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_items`
--

DROP TABLE IF EXISTS `cache_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_items` (
  `item_id` varbinary(255) NOT NULL,
  `item_data` mediumblob NOT NULL,
  `item_lifetime` int(10) unsigned DEFAULT NULL,
  `item_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_items`
--

LOCK TABLES `cache_items` WRITE;
/*!40000 ALTER TABLE `cache_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classes` (
  `id` varchar(50) NOT NULL,
  `name` varchar(190) NOT NULL DEFAULT '',
  `definitionModificationDate` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES
('brand','Brand',1759937888),
('collection','Collection',1759410362),
('product','Product',1759950125),
('warehouse','Warehouse',1759937616);
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_collectionrelations`
--

DROP TABLE IF EXISTS `classificationstore_collectionrelations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_collectionrelations` (
  `colId` int(11) unsigned NOT NULL,
  `groupId` int(11) unsigned NOT NULL,
  `sorter` int(10) DEFAULT 0,
  PRIMARY KEY (`colId`,`groupId`),
  KEY `FK_classificationstore_collectionrelations_groups` (`groupId`),
  CONSTRAINT `FK_classificationstore_collectionrelations_groups` FOREIGN KEY (`groupId`) REFERENCES `classificationstore_groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_collectionrelations`
--

LOCK TABLES `classificationstore_collectionrelations` WRITE;
/*!40000 ALTER TABLE `classificationstore_collectionrelations` DISABLE KEYS */;
INSERT INTO `classificationstore_collectionrelations` VALUES
(1,1,0),
(1,2,0),
(1,3,0),
(1,4,0),
(1,5,0),
(2,6,0),
(2,7,0);
/*!40000 ALTER TABLE `classificationstore_collectionrelations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_collections`
--

DROP TABLE IF EXISTS `classificationstore_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_collections` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `storeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `storeId` (`storeId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_collections`
--

LOCK TABLES `classificationstore_collections` WRITE;
/*!40000 ALTER TABLE `classificationstore_collections` DISABLE KEYS */;
INSERT INTO `classificationstore_collections` VALUES
(1,1,'Uniform','',1759951117,1759951117),
(2,2,'Box','',1759951553,1759951553);
/*!40000 ALTER TABLE `classificationstore_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_groups`
--

DROP TABLE IF EXISTS `classificationstore_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `storeId` int(11) DEFAULT NULL,
  `parentId` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(190) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `storeId` (`storeId`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_groups`
--

LOCK TABLES `classificationstore_groups` WRITE;
/*!40000 ALTER TABLE `classificationstore_groups` DISABLE KEYS */;
INSERT INTO `classificationstore_groups` VALUES
(1,1,0,'Belt',NULL,1759950966,1759950966),
(2,1,0,'Shirt',NULL,1759950971,1759950971),
(3,1,0,'Shoes',NULL,1759950978,1759950978),
(4,1,0,'Throuser',NULL,1759950988,1759950988),
(5,1,0,'Tshirt',NULL,1759950993,1759950993),
(6,2,0,'Box Specs',NULL,1759951502,1759951502),
(7,2,0,'Box Type',NULL,1759951508,1759951508);
/*!40000 ALTER TABLE `classificationstore_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_keys`
--

DROP TABLE IF EXISTS `classificationstore_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_keys` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `storeId` int(11) DEFAULT NULL,
  `name` varchar(190) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `type` varchar(190) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  `definition` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`definition`)),
  `enabled` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `enabled` (`enabled`),
  KEY `type` (`type`),
  KEY `storeId` (`storeId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_keys`
--

LOCK TABLES `classificationstore_keys` WRITE;
/*!40000 ALTER TABLE `classificationstore_keys` DISABLE KEYS */;
INSERT INTO `classificationstore_keys` VALUES
(1,1,'Belth Lenght','Belth Lenght',NULL,'input',1759950419,1759950419,'{\"fieldtype\":\"input\",\"name\":\"Belth Lenght\",\"title\":\"Belth Lenght\",\"datatype\":\"data\"}',1),
(2,1,'Colletto','Colletto',NULL,'select',1759950429,1759950613,'{\"name\":\"Colletto\",\"datatype\":\"data\",\"fieldtype\":\"select\",\"title\":\"Colletto\",\"options\":[{\"key\":\"Coreana\",\"value\":\"Coreana\"},{\"key\":\"Diplomatico\",\"value\":\"Diplomatico\"},{\"key\":\"Italiano\",\"value\":\"Italiano\"},{\"key\":\"Francese\",\"value\":\"Francese\"},{\"key\":\"Button-down\",\"value\":\"Button-down\"},{\"key\":\"Camp\",\"value\":\"Camp\"},{\"key\":\"Club\",\"value\":\"Club\"}],\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-3496-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":\"\",\"defaultValueGenerator\":\"\",\"optionsProviderType\":\"configure\",\"optionsProviderClass\":\"\",\"optionsProviderData\":\"\",\"combobox-3491-inputEl\":null,\"displayfield-3555-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"combobox-3550-inputEl\":null}',1),
(3,1,'Fabric','Fabric',NULL,'select',1759950459,1759950707,'{\"name\":\"Fabric\",\"datatype\":\"data\",\"fieldtype\":\"select\",\"title\":\"Fabric\",\"options\":[{\"key\":\"Cotone\",\"value\":\"Cotone\"},{\"key\":\"Lino\",\"value\":\"Lino\"},{\"key\":\"Fresco Lana\",\"value\":\"Fresco Lana\"},{\"key\":\"Jeans\",\"value\":\"Jeans\"},{\"key\":\"Poliestere\",\"value\":\"Poliestere\"}],\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-3599-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":\"\",\"defaultValueGenerator\":\"\",\"optionsProviderType\":\"configure\",\"optionsProviderClass\":\"\",\"optionsProviderData\":\"\",\"combobox-3594-inputEl\":null}',1),
(4,1,'Shirt - Size','Shirt - Size',NULL,'select',1759950474,1759950762,'{\"name\":\"Shirt - Size\",\"datatype\":\"data\",\"fieldtype\":\"select\",\"title\":\"Shirt - Size\",\"options\":[{\"key\":\"38\",\"value\":\"38\"},{\"key\":\"39\",\"value\":\"39\"},{\"key\":\"40\",\"value\":\"40\"},{\"key\":\"41\",\"value\":\"41\"},{\"key\":\"42\",\"value\":\"42\"}],\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-3643-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":\"\",\"defaultValueGenerator\":\"\",\"optionsProviderType\":\"configure\",\"optionsProviderClass\":\"\",\"optionsProviderData\":\"\",\"combobox-3638-inputEl\":null}',1),
(5,1,'Shoe - Size','Shoe - Size',NULL,'select',1759950484,1759950833,'{\"name\":\"Shoe - Size\",\"datatype\":\"data\",\"fieldtype\":\"select\",\"title\":\"Shoe - Size\",\"options\":[{\"key\":\"40\",\"value\":\"40\"},{\"key\":\"41\",\"value\":\"41\"},{\"key\":\"42\",\"value\":\"42\"},{\"key\":\"43\",\"value\":\"43\"},{\"key\":\"44\",\"value\":\"44\"},{\"key\":\"45\",\"value\":\"45\"}],\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-3687-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":\"\",\"defaultValueGenerator\":\"\",\"optionsProviderType\":\"configure\",\"optionsProviderClass\":\"\",\"optionsProviderData\":\"\",\"combobox-3682-inputEl\":null}',1),
(6,1,'Throuser - Size','Throuser - Size',NULL,'select',1759950493,1759950877,'{\"name\":\"Throuser - Size\",\"datatype\":\"data\",\"fieldtype\":\"select\",\"title\":\"Throuser - Size\",\"options\":[{\"key\":\"38\",\"value\":\"38\"},{\"key\":\"39\",\"value\":\"39\"},{\"key\":\"40\",\"value\":\"40\"},{\"key\":\"41\",\"value\":\"41\"},{\"key\":\"42\",\"value\":\"42\"}],\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-3731-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":\"\",\"defaultValueGenerator\":\"\",\"optionsProviderType\":\"configure\",\"optionsProviderClass\":\"\",\"optionsProviderData\":\"\",\"combobox-3726-inputEl\":null}',1),
(7,1,'TShirt - Size','TShirt - Size',NULL,'select',1759950502,1759950924,'{\"name\":\"TShirt - Size\",\"datatype\":\"data\",\"fieldtype\":\"select\",\"title\":\"TShirt - Size\",\"options\":[{\"key\":\"XS\",\"value\":\"XS\"},{\"key\":\"S\",\"value\":\"S\"},{\"key\":\"M\",\"value\":\"M\"},{\"key\":\"L\",\"value\":\"L\"},{\"key\":\"XL\",\"value\":\"XL\"}],\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-3801-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":\"\",\"defaultValueGenerator\":\"\",\"optionsProviderType\":\"configure\",\"optionsProviderClass\":\"\",\"optionsProviderData\":\"\",\"combobox-3796-inputEl\":null}',1),
(8,2,'boxHeight','boxHeight',NULL,'numeric',1759951170,1759951411,'{\"name\":\"boxHeight\",\"datatype\":\"data\",\"fieldtype\":\"numeric\",\"title\":\"boxHeight\",\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"unique\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-4251-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":null,\"defaultValueGenerator\":\"\",\"decimalSize\":null,\"decimalPrecision\":null,\"integer\":false,\"unsigned\":true,\"minValue\":null,\"maxValue\":null,\"displayfield-4590-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\"}',1),
(9,2,'boxWidth','boxWidth',NULL,'numeric',1759951204,1759951405,'{\"name\":\"boxWidth\",\"datatype\":\"data\",\"fieldtype\":\"numeric\",\"title\":\"boxWidth\",\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"unique\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-4285-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":null,\"defaultValueGenerator\":\"\",\"decimalSize\":null,\"decimalPrecision\":null,\"integer\":false,\"unsigned\":true,\"minValue\":null,\"maxValue\":null,\"displayfield-4556-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\"}',1),
(10,2,'boxDepth','boxDepth',NULL,'numeric',1759951219,1759951414,'{\"name\":\"boxDepth\",\"datatype\":\"data\",\"fieldtype\":\"numeric\",\"title\":\"boxDepth\",\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"unique\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-4319-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":null,\"defaultValueGenerator\":\"\",\"decimalSize\":null,\"decimalPrecision\":null,\"integer\":false,\"unsigned\":true,\"minValue\":null,\"maxValue\":null,\"displayfield-4522-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"displayfield-4624-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\"}',1),
(11,2,'boxWeight','boxWeight',NULL,'inputQuantityValue',1759951238,1759951330,'{\"name\":\"boxWeight\",\"datatype\":\"data\",\"fieldtype\":\"inputQuantityValue\",\"title\":\"boxWeight\",\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-4352-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":\"\",\"defaultUnit\":\"Grams\",\"validUnits\":[\"Grams\",\"Kilograms\",\"Tons\"],\"displayfield-4422-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"displayfield-4450-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\"}',1),
(12,2,'boxMaterial','boxMaterial',NULL,'select',1759951262,1759951378,'{\"name\":\"boxMaterial\",\"datatype\":\"data\",\"fieldtype\":\"select\",\"title\":\"boxMaterial\",\"options\":[{\"key\":\"Cardboard\",\"value\":\"Cardboard\"},{\"key\":\"Metal Tin\",\"value\":\"Metal Tin\"},{\"key\":\"Plastic\",\"value\":\"Plastic\"},{\"key\":\"Wood\",\"value\":\"Wood\"}],\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-4398-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":\"\",\"defaultValueGenerator\":\"\",\"optionsProviderType\":\"configure\",\"optionsProviderClass\":\"\",\"optionsProviderData\":\"\",\"combobox-4393-inputEl\":null,\"displayfield-4496-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"combobox-4491-inputEl\":null}',1);
/*!40000 ALTER TABLE `classificationstore_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_relations`
--

DROP TABLE IF EXISTS `classificationstore_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_relations` (
  `groupId` int(11) unsigned NOT NULL,
  `keyId` int(11) unsigned NOT NULL,
  `sorter` int(11) DEFAULT NULL,
  `mandatory` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`groupId`,`keyId`),
  KEY `FK_classificationstore_relations_classificationstore_keys` (`keyId`),
  KEY `mandatory` (`mandatory`),
  CONSTRAINT `FK_classificationstore_relations_classificationstore_groups` FOREIGN KEY (`groupId`) REFERENCES `classificationstore_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_classificationstore_relations_classificationstore_keys` FOREIGN KEY (`keyId`) REFERENCES `classificationstore_keys` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_relations`
--

LOCK TABLES `classificationstore_relations` WRITE;
/*!40000 ALTER TABLE `classificationstore_relations` DISABLE KEYS */;
INSERT INTO `classificationstore_relations` VALUES
(1,1,0,0),
(1,3,0,0),
(2,2,0,0),
(2,3,0,0),
(2,4,0,0),
(3,3,0,0),
(3,5,0,0),
(4,3,0,0),
(4,6,0,0),
(5,3,0,0),
(5,7,0,0),
(6,8,0,0),
(6,9,0,0),
(6,10,0,0),
(6,11,0,0),
(7,12,0,0);
/*!40000 ALTER TABLE `classificationstore_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_stores`
--

DROP TABLE IF EXISTS `classificationstore_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_stores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_stores`
--

LOCK TABLES `classificationstore_stores` WRITE;
/*!40000 ALTER TABLE `classificationstore_stores` DISABLE KEYS */;
INSERT INTO `classificationstore_stores` VALUES
(1,'Product',NULL),
(2,'Shipping',NULL);
/*!40000 ALTER TABLE `classificationstore_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dependencies`
--

DROP TABLE IF EXISTS `dependencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dependencies` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sourcetype` enum('document','asset','object') NOT NULL DEFAULT 'document',
  `sourceid` int(11) unsigned NOT NULL DEFAULT 0,
  `targettype` enum('document','asset','object') NOT NULL DEFAULT 'document',
  `targetid` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `combi` (`sourcetype`,`sourceid`,`targettype`,`targetid`),
  KEY `targettype_targetid` (`targettype`,`targetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dependencies`
--

LOCK TABLES `dependencies` WRITE;
/*!40000 ALTER TABLE `dependencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `dependencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned DEFAULT NULL,
  `type` enum('page','link','snippet','folder','hardlink','email') DEFAULT NULL,
  `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
  `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `index` int(11) unsigned DEFAULT 0,
  `published` tinyint(1) unsigned DEFAULT 1,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fullpath` (`path`,`key`),
  KEY `parentId` (`parentId`),
  KEY `key` (`key`),
  KEY `published` (`published`),
  KEY `modificationDate` (`modificationDate`),
  KEY `versionCount` (`versionCount`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES
(1,0,'page','','/',999999,1,1759936097,1759936097,1,1,0);
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_editables`
--

DROP TABLE IF EXISTS `documents_editables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_editables` (
  `documentId` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(750) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL DEFAULT '',
  `type` varchar(50) DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  PRIMARY KEY (`documentId`,`name`),
  CONSTRAINT `fk_documents_editables_documents` FOREIGN KEY (`documentId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_editables`
--

LOCK TABLES `documents_editables` WRITE;
/*!40000 ALTER TABLE `documents_editables` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_editables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_email`
--

DROP TABLE IF EXISTS `documents_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_email` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `controller` varchar(500) DEFAULT NULL,
  `template` varchar(255) DEFAULT NULL,
  `to` varchar(255) DEFAULT NULL,
  `from` varchar(255) DEFAULT NULL,
  `replyTo` varchar(255) DEFAULT NULL,
  `cc` varchar(255) DEFAULT NULL,
  `bcc` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_documents_email_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_email`
--

LOCK TABLES `documents_email` WRITE;
/*!40000 ALTER TABLE `documents_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_hardlink`
--

DROP TABLE IF EXISTS `documents_hardlink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_hardlink` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `sourceId` int(11) DEFAULT NULL,
  `propertiesFromSource` tinyint(1) DEFAULT NULL,
  `childrenFromSource` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sourceId` (`sourceId`),
  CONSTRAINT `fk_documents_hardlink_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_hardlink`
--

LOCK TABLES `documents_hardlink` WRITE;
/*!40000 ALTER TABLE `documents_hardlink` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_hardlink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_link`
--

DROP TABLE IF EXISTS `documents_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_link` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `internalType` enum('document','asset','object') DEFAULT NULL,
  `internal` int(11) unsigned DEFAULT NULL,
  `direct` varchar(1000) DEFAULT NULL,
  `linktype` enum('direct','internal') DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_documents_link_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_link`
--

LOCK TABLES `documents_link` WRITE;
/*!40000 ALTER TABLE `documents_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_page`
--

DROP TABLE IF EXISTS `documents_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_page` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `controller` varchar(500) DEFAULT NULL,
  `template` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(383) DEFAULT NULL,
  `prettyUrl` varchar(255) DEFAULT NULL,
  `contentMainDocumentId` int(11) DEFAULT NULL,
  `targetGroupIds` varchar(255) NOT NULL DEFAULT '',
  `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
  `staticGeneratorEnabled` tinyint(1) unsigned DEFAULT NULL,
  `staticGeneratorLifetime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prettyUrl` (`prettyUrl`),
  CONSTRAINT `fk_documents_page_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_page`
--

LOCK TABLES `documents_page` WRITE;
/*!40000 ALTER TABLE `documents_page` DISABLE KEYS */;
INSERT INTO `documents_page` VALUES
(1,'App\\Controller\\DefaultController::defaultAction','','','',NULL,NULL,'',NULL,NULL,NULL);
/*!40000 ALTER TABLE `documents_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_snippet`
--

DROP TABLE IF EXISTS `documents_snippet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_snippet` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `controller` varchar(500) DEFAULT NULL,
  `template` varchar(255) DEFAULT NULL,
  `contentMainDocumentId` int(11) DEFAULT NULL,
  `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_documents_snippet_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_snippet`
--

LOCK TABLES `documents_snippet` WRITE;
/*!40000 ALTER TABLE `documents_snippet` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_snippet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_translations`
--

DROP TABLE IF EXISTS `documents_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_translations` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `sourceId` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`sourceId`,`language`),
  KEY `id` (`id`),
  KEY `language` (`language`),
  CONSTRAINT `fk_documents_translations_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_translations`
--

LOCK TABLES `documents_translations` WRITE;
/*!40000 ALTER TABLE `documents_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edit_lock`
--

DROP TABLE IF EXISTS `edit_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `edit_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) unsigned NOT NULL DEFAULT 0,
  `ctype` enum('document','asset','object') DEFAULT NULL,
  `userId` int(11) unsigned NOT NULL DEFAULT 0,
  `sessionId` varchar(255) DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ctype` (`ctype`),
  KEY `cidtype` (`cid`,`ctype`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edit_lock`
--

LOCK TABLES `edit_lock` WRITE;
/*!40000 ALTER TABLE `edit_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `edit_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `element_workflow_state`
--

DROP TABLE IF EXISTS `element_workflow_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `element_workflow_state` (
  `cid` int(10) NOT NULL DEFAULT 0,
  `ctype` enum('document','asset','object') NOT NULL,
  `place` text DEFAULT NULL,
  `workflow` varchar(100) NOT NULL,
  PRIMARY KEY (`cid`,`ctype`,`workflow`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `element_workflow_state`
--

LOCK TABLES `element_workflow_state` WRITE;
/*!40000 ALTER TABLE `element_workflow_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `element_workflow_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_blocklist`
--

DROP TABLE IF EXISTS `email_blocklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_blocklist` (
  `address` varchar(190) NOT NULL DEFAULT '',
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_blocklist`
--

LOCK TABLES `email_blocklist` WRITE;
/*!40000 ALTER TABLE `email_blocklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_blocklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log`
--

DROP TABLE IF EXISTS `email_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `documentId` int(11) unsigned DEFAULT NULL,
  `requestUri` varchar(500) DEFAULT NULL,
  `params` text DEFAULT NULL,
  `from` varchar(500) DEFAULT NULL,
  `replyTo` varchar(255) DEFAULT NULL,
  `to` longtext DEFAULT NULL,
  `cc` longtext DEFAULT NULL,
  `bcc` longtext DEFAULT NULL,
  `sentDate` int(11) unsigned DEFAULT NULL,
  `subject` varchar(500) DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sentDate` (`sentDate`,`id`),
  KEY `document_id` (`documentId`),
  FULLTEXT KEY `fulltext` (`from`,`to`,`cc`,`bcc`,`subject`,`params`),
  CONSTRAINT `fk_email_log_documents` FOREIGN KEY (`documentId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log`
--

LOCK TABLES `email_log` WRITE;
/*!40000 ALTER TABLE `email_log` DISABLE KEYS */;
INSERT INTO `email_log` VALUES
(1,NULL,'/admin/email/send-test-email','[]','test@testi.it',NULL,'test@grazie.it',NULL,NULL,1759937120,'test',NULL);
/*!40000 ALTER TABLE `email_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfig_favourites`
--

DROP TABLE IF EXISTS `gridconfig_favourites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gridconfig_favourites` (
  `ownerId` int(11) NOT NULL,
  `classId` varchar(50) NOT NULL,
  `objectId` int(11) NOT NULL DEFAULT 0,
  `gridConfigId` int(11) NOT NULL,
  `searchType` varchar(50) NOT NULL DEFAULT '',
  `type` enum('asset','object') NOT NULL DEFAULT 'object',
  PRIMARY KEY (`ownerId`,`classId`,`searchType`,`objectId`),
  KEY `classId` (`classId`),
  KEY `searchType` (`searchType`),
  KEY `grid_config_id` (`gridConfigId`),
  CONSTRAINT `fk_gridconfig_favourites_gridconfigs` FOREIGN KEY (`gridConfigId`) REFERENCES `gridconfigs` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfig_favourites`
--

LOCK TABLES `gridconfig_favourites` WRITE;
/*!40000 ALTER TABLE `gridconfig_favourites` DISABLE KEYS */;
/*!40000 ALTER TABLE `gridconfig_favourites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfig_shares`
--

DROP TABLE IF EXISTS `gridconfig_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gridconfig_shares` (
  `gridConfigId` int(11) NOT NULL,
  `sharedWithUserId` int(11) NOT NULL,
  PRIMARY KEY (`gridConfigId`,`sharedWithUserId`),
  KEY `sharedWithUserId` (`sharedWithUserId`),
  KEY `grid_config_id` (`gridConfigId`),
  CONSTRAINT `fk_gridconfig_shares_gridconfigs` FOREIGN KEY (`gridConfigId`) REFERENCES `gridconfigs` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfig_shares`
--

LOCK TABLES `gridconfig_shares` WRITE;
/*!40000 ALTER TABLE `gridconfig_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `gridconfig_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfigs`
--

DROP TABLE IF EXISTS `gridconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gridconfigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ownerId` int(11) DEFAULT NULL,
  `classId` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `searchType` varchar(50) DEFAULT NULL,
  `type` enum('asset','object') NOT NULL DEFAULT 'object',
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `description` longtext DEFAULT NULL,
  `creationDate` int(11) DEFAULT NULL,
  `modificationDate` int(11) DEFAULT NULL,
  `shareGlobally` tinyint(1) DEFAULT NULL,
  `setAsFavourite` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ownerId` (`ownerId`),
  KEY `classId` (`classId`),
  KEY `searchType` (`searchType`),
  KEY `shareGlobally` (`shareGlobally`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfigs`
--

LOCK TABLES `gridconfigs` WRITE;
/*!40000 ALTER TABLE `gridconfigs` DISABLE KEYS */;
/*!40000 ALTER TABLE `gridconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importconfig_shares`
--

DROP TABLE IF EXISTS `importconfig_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `importconfig_shares` (
  `importConfigId` int(11) NOT NULL,
  `sharedWithUserId` int(11) NOT NULL,
  PRIMARY KEY (`importConfigId`,`sharedWithUserId`),
  KEY `sharedWithUserId` (`sharedWithUserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importconfig_shares`
--

LOCK TABLES `importconfig_shares` WRITE;
/*!40000 ALTER TABLE `importconfig_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `importconfig_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importconfigs`
--

DROP TABLE IF EXISTS `importconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `importconfigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ownerId` int(11) DEFAULT NULL,
  `classId` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `description` longtext DEFAULT NULL,
  `creationDate` int(11) DEFAULT NULL,
  `modificationDate` int(11) DEFAULT NULL,
  `shareGlobally` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ownerId` (`ownerId`),
  KEY `classId` (`classId`),
  KEY `shareGlobally` (`shareGlobally`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importconfigs`
--

LOCK TABLES `importconfigs` WRITE;
/*!40000 ALTER TABLE `importconfigs` DISABLE KEYS */;
/*!40000 ALTER TABLE `importconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lock_keys`
--

DROP TABLE IF EXISTS `lock_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lock_keys` (
  `key_id` varchar(64) NOT NULL,
  `key_token` varchar(44) NOT NULL,
  `key_expiration` int(10) unsigned NOT NULL,
  PRIMARY KEY (`key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lock_keys`
--

LOCK TABLES `lock_keys` WRITE;
/*!40000 ALTER TABLE `lock_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `lock_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `available_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `delivered_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
INSERT INTO `messenger_messages` VALUES
(1,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:2;}}','[]','pimcore_search_backend_message','2025-10-08 18:56:01','2025-10-08 18:56:01',NULL),
(2,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:38:\\\"Pimcore\\\\Messenger\\\\VersionDeleteMessage\\\":2:{s:14:\\\"\\0*\\0elementType\\\";s:6:\\\"object\\\";s:12:\\\"\\0*\\0elementId\\\";i:2;}}','[]','pimcore_core','2025-10-08 18:56:38','2025-10-08 18:56:38',NULL);
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migration_versions` (
  `version` varchar(1024) NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_versions`
--

LOCK TABLES `migration_versions` WRITE;
/*!40000 ALTER TABLE `migration_versions` DISABLE KEYS */;
INSERT INTO `migration_versions` VALUES
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201007000000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008082752',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008091131',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008101817',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008132324',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201009095924',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201012154224',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201014101437',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201113143914',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201201084201',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210218142556',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210323082921',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210323110055',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210324152821',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210324152822',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210330132354',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210408153226',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210412112812',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210428145320',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210505093841',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210531125102',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210608094532',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210616114744',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210624085031',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210630062445',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210702102100',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210901130000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210928135248',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211016084043',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211018104331',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211028134037',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211028155535',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211103055110',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211209131141',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211221152344',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220119082511',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220120121803',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220120162621',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220201132131',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220214110000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220317125711',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220318101020',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220402104849',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220411172543',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220419120333',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220425082914',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220502104200',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220506103100',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220511085800',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220614115124',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220617145524',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220718162200',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220725154615',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220809154926',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220809164000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220816120101',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220829132224',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220830105212',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220906111031',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220908113752',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221003115124',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221005090000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221019042134',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221020195451',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221025165133',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221028115803',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221107084519',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221116115427',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221129084031',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221215071650',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221216140012',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221220152444',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221222134837',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221222181745',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221228101109',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230107224432',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230110130748',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230111074323',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230113165612',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230120111111',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230124120641',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230125164101',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230202152342',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230221073317',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230222075502',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230222174636',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230223101848',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230320110429',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230320131322',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230321133700',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230322114936',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230405162853',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230406113010',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230424084415',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230428112302',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230517115427',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230525131748',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230615103905',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230616085142',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230913173812',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20231127124738',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240131080600',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240222143211',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240229152000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240606165618',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240708083500',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240813085200',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20241021111028',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20241025101923',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20241114142759',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20250416120333',NULL,NULL);
/*!40000 ALTER TABLE `migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `ctype` enum('asset','document','object') DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `locked` tinyint(1) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `cid_ctype` (`cid`,`ctype`),
  KEY `date` (`date`),
  KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes_data`
--

DROP TABLE IF EXISTS `notes_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes_data` (
  `auto_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('text','date','document','asset','object','bool') DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`auto_id`),
  UNIQUE KEY `UNIQ_E5A8E5E2BF3967505E237E06` (`id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes_data`
--

LOCK TABLES `notes_data` WRITE;
/*!40000 ALTER TABLE `notes_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL DEFAULT 'info',
  `title` varchar(250) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `sender` int(11) DEFAULT NULL,
  `recipient` int(11) NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `modificationDate` timestamp NULL DEFAULT NULL,
  `linkedElementType` enum('document','asset','object') DEFAULT NULL,
  `linkedElement` int(11) DEFAULT NULL,
  `payload` longtext DEFAULT NULL,
  `isStudio` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `recipient` (`recipient`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `object_brand`
--

DROP TABLE IF EXISTS `object_brand`;
/*!50001 DROP VIEW IF EXISTS `object_brand`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_brand` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `products`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `object_brick_query_productRelations_product`
--

DROP TABLE IF EXISTS `object_brick_query_productRelations_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_brick_query_productRelations_product` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `fieldname` varchar(190) NOT NULL DEFAULT '',
  `related` text DEFAULT NULL,
  `alternatives` text DEFAULT NULL,
  PRIMARY KEY (`id`,`fieldname`),
  KEY `id` (`id`),
  KEY `fieldname` (`fieldname`),
  CONSTRAINT `fk_object_brick_query_productRelations_product__id` FOREIGN KEY (`id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_brick_query_productRelations_product`
--

LOCK TABLES `object_brick_query_productRelations_product` WRITE;
/*!40000 ALTER TABLE `object_brick_query_productRelations_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_brick_query_productRelations_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_brick_store_productRelations_product`
--

DROP TABLE IF EXISTS `object_brick_store_productRelations_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_brick_store_productRelations_product` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `fieldname` varchar(190) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`,`fieldname`),
  KEY `id` (`id`),
  KEY `fieldname` (`fieldname`),
  CONSTRAINT `fk_object_brick_store_productRelations_product__id` FOREIGN KEY (`id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_brick_store_productRelations_product`
--

LOCK TABLES `object_brick_store_productRelations_product` WRITE;
/*!40000 ALTER TABLE `object_brick_store_productRelations_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_brick_store_productRelations_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_classificationstore_data_product`
--

DROP TABLE IF EXISTS `object_classificationstore_data_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_classificationstore_data_product` (
  `id` int(11) unsigned NOT NULL,
  `collectionId` bigint(20) DEFAULT NULL,
  `groupId` int(11) unsigned NOT NULL,
  `keyId` bigint(20) NOT NULL,
  `value` longtext DEFAULT NULL,
  `value2` longtext DEFAULT NULL,
  `fieldname` varchar(70) NOT NULL,
  `language` varchar(10) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`,`fieldname`,`groupId`,`keyId`,`language`),
  KEY `keyId` (`keyId`),
  KEY `language` (`language`),
  KEY `groupKeys` (`id`,`fieldname`,`groupId`),
  CONSTRAINT `fk_object_classificationstore_data_product__id` FOREIGN KEY (`id`) REFERENCES `objects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_object_classificationstore_data_product__id__fieldna_17656780` FOREIGN KEY (`id`, `fieldname`, `groupId`) REFERENCES `object_classificationstore_groups_product` (`id`, `fieldname`, `groupId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_classificationstore_data_product`
--

LOCK TABLES `object_classificationstore_data_product` WRITE;
/*!40000 ALTER TABLE `object_classificationstore_data_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_classificationstore_data_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_classificationstore_groups_product`
--

DROP TABLE IF EXISTS `object_classificationstore_groups_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_classificationstore_groups_product` (
  `id` int(11) unsigned NOT NULL,
  `groupId` int(11) unsigned NOT NULL,
  `fieldname` varchar(70) NOT NULL,
  PRIMARY KEY (`id`,`fieldname`,`groupId`),
  KEY `fk_object_classificationstore_groups_product__groupId` (`groupId`),
  CONSTRAINT `fk_object_classificationstore_groups_product__groupId` FOREIGN KEY (`groupId`) REFERENCES `classificationstore_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_object_classificationstore_groups_product__id` FOREIGN KEY (`id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_classificationstore_groups_product`
--

LOCK TABLES `object_classificationstore_groups_product` WRITE;
/*!40000 ALTER TABLE `object_classificationstore_groups_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_classificationstore_groups_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `object_collection`
--

DROP TABLE IF EXISTS `object_collection`;
/*!50001 DROP VIEW IF EXISTS `object_collection`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_collection` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `name`,
  1 AS `validity__start_date`,
  1 AS `validity__end_date`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `object_collection_warehouseAvailability_product`
--

DROP TABLE IF EXISTS `object_collection_warehouseAvailability_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_collection_warehouseAvailability_product` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `index` int(11) NOT NULL DEFAULT 0,
  `fieldname` varchar(190) NOT NULL DEFAULT '',
  `quantity__value` bigint(20) DEFAULT NULL,
  `quantity__unit` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`,`index`,`fieldname`),
  KEY `index` (`index`),
  KEY `fieldname` (`fieldname`),
  CONSTRAINT `fk_object_collection_warehouseAvailability_product__id` FOREIGN KEY (`id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_collection_warehouseAvailability_product`
--

LOCK TABLES `object_collection_warehouseAvailability_product` WRITE;
/*!40000 ALTER TABLE `object_collection_warehouseAvailability_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_collection_warehouseAvailability_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `object_localized_brand_de`
--

DROP TABLE IF EXISTS `object_localized_brand_de`;
/*!50001 DROP VIEW IF EXISTS `object_localized_brand_de`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_brand_de` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `products`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `brandName` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_brand_en`
--

DROP TABLE IF EXISTS `object_localized_brand_en`;
/*!50001 DROP VIEW IF EXISTS `object_localized_brand_en`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_brand_en` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `products`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `brandName` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_brand_fr`
--

DROP TABLE IF EXISTS `object_localized_brand_fr`;
/*!50001 DROP VIEW IF EXISTS `object_localized_brand_fr`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_brand_fr` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `products`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `brandName` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `object_localized_data_brand`
--

DROP TABLE IF EXISTS `object_localized_data_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_data_brand` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `brandName` varchar(190) DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_data_brand__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_data_brand`
--

LOCK TABLES `object_localized_data_brand` WRITE;
/*!40000 ALTER TABLE `object_localized_data_brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_localized_data_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_data_product`
--

DROP TABLE IF EXISTS `object_localized_data_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_data_product` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `name` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_data_product__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_data_product`
--

LOCK TABLES `object_localized_data_product` WRITE;
/*!40000 ALTER TABLE `object_localized_data_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_localized_data_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `object_localized_product_de`
--

DROP TABLE IF EXISTS `object_localized_product_de`;
/*!50001 DROP VIEW IF EXISTS `object_localized_product_de`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_product_de` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `sku`,
  1 AS `brand__id`,
  1 AS `brand__type`,
  1 AS `Color`,
  1 AS `mainImage`,
  1 AS `gallery__images`,
  1 AS `gallery__hotspots`,
  1 AS `collections`,
  1 AS `files`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `name`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_product_en`
--

DROP TABLE IF EXISTS `object_localized_product_en`;
/*!50001 DROP VIEW IF EXISTS `object_localized_product_en`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_product_en` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `sku`,
  1 AS `brand__id`,
  1 AS `brand__type`,
  1 AS `Color`,
  1 AS `mainImage`,
  1 AS `gallery__images`,
  1 AS `gallery__hotspots`,
  1 AS `collections`,
  1 AS `files`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `name`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_product_fr`
--

DROP TABLE IF EXISTS `object_localized_product_fr`;
/*!50001 DROP VIEW IF EXISTS `object_localized_product_fr`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_product_fr` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `sku`,
  1 AS `brand__id`,
  1 AS `brand__type`,
  1 AS `Color`,
  1 AS `mainImage`,
  1 AS `gallery__images`,
  1 AS `gallery__hotspots`,
  1 AS `collections`,
  1 AS `files`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `name`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `object_localized_query_brand_de`
--

DROP TABLE IF EXISTS `object_localized_query_brand_de`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_brand_de` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `brandName` varchar(190) DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_brand_de__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_brand_de`
--

LOCK TABLES `object_localized_query_brand_de` WRITE;
/*!40000 ALTER TABLE `object_localized_query_brand_de` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_localized_query_brand_de` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_brand_en`
--

DROP TABLE IF EXISTS `object_localized_query_brand_en`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_brand_en` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `brandName` varchar(190) DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_brand_en__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_brand_en`
--

LOCK TABLES `object_localized_query_brand_en` WRITE;
/*!40000 ALTER TABLE `object_localized_query_brand_en` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_localized_query_brand_en` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_brand_fr`
--

DROP TABLE IF EXISTS `object_localized_query_brand_fr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_brand_fr` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `brandName` varchar(190) DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_brand_fr__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_brand_fr`
--

LOCK TABLES `object_localized_query_brand_fr` WRITE;
/*!40000 ALTER TABLE `object_localized_query_brand_fr` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_localized_query_brand_fr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_product_de`
--

DROP TABLE IF EXISTS `object_localized_query_product_de`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_product_de` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `name` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_product_de__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_product_de`
--

LOCK TABLES `object_localized_query_product_de` WRITE;
/*!40000 ALTER TABLE `object_localized_query_product_de` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_localized_query_product_de` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_product_en`
--

DROP TABLE IF EXISTS `object_localized_query_product_en`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_product_en` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `name` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_product_en__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_product_en`
--

LOCK TABLES `object_localized_query_product_en` WRITE;
/*!40000 ALTER TABLE `object_localized_query_product_en` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_localized_query_product_en` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_product_fr`
--

DROP TABLE IF EXISTS `object_localized_query_product_fr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_product_fr` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `name` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_product_fr__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_product_fr`
--

LOCK TABLES `object_localized_query_product_fr` WRITE;
/*!40000 ALTER TABLE `object_localized_query_product_fr` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_localized_query_product_fr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `object_product`
--

DROP TABLE IF EXISTS `object_product`;
/*!50001 DROP VIEW IF EXISTS `object_product`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_product` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `sku`,
  1 AS `brand__id`,
  1 AS `brand__type`,
  1 AS `Color`,
  1 AS `mainImage`,
  1 AS `gallery__images`,
  1 AS `gallery__hotspots`,
  1 AS `collections`,
  1 AS `files`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `object_query_brand`
--

DROP TABLE IF EXISTS `object_query_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_query_brand` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `oo_classId` varchar(50) DEFAULT 'brand',
  `oo_className` varchar(255) DEFAULT 'Brand',
  `products` text DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_query_brand__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_query_brand`
--

LOCK TABLES `object_query_brand` WRITE;
/*!40000 ALTER TABLE `object_query_brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_query_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_query_collection`
--

DROP TABLE IF EXISTS `object_query_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_query_collection` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `oo_classId` varchar(50) DEFAULT 'collection',
  `oo_className` varchar(255) DEFAULT 'Collection',
  `name` varchar(190) DEFAULT NULL,
  `validity__start_date` bigint(20) DEFAULT NULL,
  `validity__end_date` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_query_collection__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_query_collection`
--

LOCK TABLES `object_query_collection` WRITE;
/*!40000 ALTER TABLE `object_query_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_query_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_query_product`
--

DROP TABLE IF EXISTS `object_query_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_query_product` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `oo_classId` varchar(50) DEFAULT 'product',
  `oo_className` varchar(255) DEFAULT 'Product',
  `sku` varchar(190) DEFAULT NULL,
  `brand__id` int(11) DEFAULT NULL,
  `brand__type` enum('document','asset','object') DEFAULT NULL,
  `Color` varchar(190) DEFAULT NULL,
  `mainImage` int(11) DEFAULT NULL,
  `gallery__images` text DEFAULT NULL,
  `gallery__hotspots` longtext DEFAULT NULL,
  `collections` text DEFAULT NULL,
  `files` text DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  KEY `p_index_sku` (`sku`),
  CONSTRAINT `fk_object_query_product__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_query_product`
--

LOCK TABLES `object_query_product` WRITE;
/*!40000 ALTER TABLE `object_query_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_query_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_query_warehouse`
--

DROP TABLE IF EXISTS `object_query_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_query_warehouse` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `oo_classId` varchar(50) DEFAULT 'warehouse',
  `oo_className` varchar(255) DEFAULT 'Warehouse',
  `name` varchar(190) DEFAULT NULL,
  `location__longitude` double DEFAULT NULL,
  `location__latitude` double DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_query_warehouse__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_query_warehouse`
--

LOCK TABLES `object_query_warehouse` WRITE;
/*!40000 ALTER TABLE `object_query_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_query_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_relations_brand`
--

DROP TABLE IF EXISTS `object_relations_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_relations_brand` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `src_id` int(11) unsigned NOT NULL DEFAULT 0,
  `dest_id` int(11) unsigned NOT NULL DEFAULT 0,
  `type` enum('object','asset','document') NOT NULL,
  `fieldname` varchar(70) NOT NULL DEFAULT '0',
  `index` int(11) unsigned NOT NULL DEFAULT 0,
  `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
  `ownername` varchar(70) NOT NULL DEFAULT '',
  `position` varchar(70) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `forward_lookup` (`src_id`,`ownertype`,`ownername`,`position`),
  KEY `reverse_lookup` (`dest_id`,`type`),
  KEY `fieldname` (`fieldname`),
  CONSTRAINT `fk_object_relations_brand__src_id` FOREIGN KEY (`src_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_relations_brand`
--

LOCK TABLES `object_relations_brand` WRITE;
/*!40000 ALTER TABLE `object_relations_brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_relations_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_relations_collection`
--

DROP TABLE IF EXISTS `object_relations_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_relations_collection` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `src_id` int(11) unsigned NOT NULL DEFAULT 0,
  `dest_id` int(11) unsigned NOT NULL DEFAULT 0,
  `type` enum('object','asset','document') NOT NULL,
  `fieldname` varchar(70) NOT NULL DEFAULT '0',
  `index` int(11) unsigned NOT NULL DEFAULT 0,
  `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
  `ownername` varchar(70) NOT NULL DEFAULT '',
  `position` varchar(70) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `forward_lookup` (`src_id`,`ownertype`,`ownername`,`position`),
  KEY `reverse_lookup` (`dest_id`,`type`),
  KEY `fieldname` (`fieldname`),
  CONSTRAINT `fk_object_relations_collection__src_id` FOREIGN KEY (`src_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_relations_collection`
--

LOCK TABLES `object_relations_collection` WRITE;
/*!40000 ALTER TABLE `object_relations_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_relations_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_relations_product`
--

DROP TABLE IF EXISTS `object_relations_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_relations_product` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `src_id` int(11) unsigned NOT NULL DEFAULT 0,
  `dest_id` int(11) unsigned NOT NULL DEFAULT 0,
  `type` enum('object','asset','document') NOT NULL,
  `fieldname` varchar(70) NOT NULL DEFAULT '0',
  `index` int(11) unsigned NOT NULL DEFAULT 0,
  `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
  `ownername` varchar(70) NOT NULL DEFAULT '',
  `position` varchar(70) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `forward_lookup` (`src_id`,`ownertype`,`ownername`,`position`),
  KEY `reverse_lookup` (`dest_id`,`type`),
  KEY `fieldname` (`fieldname`),
  CONSTRAINT `fk_object_relations_product__src_id` FOREIGN KEY (`src_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_relations_product`
--

LOCK TABLES `object_relations_product` WRITE;
/*!40000 ALTER TABLE `object_relations_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_relations_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_relations_warehouse`
--

DROP TABLE IF EXISTS `object_relations_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_relations_warehouse` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `src_id` int(11) unsigned NOT NULL DEFAULT 0,
  `dest_id` int(11) unsigned NOT NULL DEFAULT 0,
  `type` enum('object','asset','document') NOT NULL,
  `fieldname` varchar(70) NOT NULL DEFAULT '0',
  `index` int(11) unsigned NOT NULL DEFAULT 0,
  `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
  `ownername` varchar(70) NOT NULL DEFAULT '',
  `position` varchar(70) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `forward_lookup` (`src_id`,`ownertype`,`ownername`,`position`),
  KEY `reverse_lookup` (`dest_id`,`type`),
  KEY `fieldname` (`fieldname`),
  CONSTRAINT `fk_object_relations_warehouse__src_id` FOREIGN KEY (`src_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_relations_warehouse`
--

LOCK TABLES `object_relations_warehouse` WRITE;
/*!40000 ALTER TABLE `object_relations_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_relations_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_store_brand`
--

DROP TABLE IF EXISTS `object_store_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_store_brand` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_store_brand__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_store_brand`
--

LOCK TABLES `object_store_brand` WRITE;
/*!40000 ALTER TABLE `object_store_brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_store_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_store_collection`
--

DROP TABLE IF EXISTS `object_store_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_store_collection` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(190) DEFAULT NULL,
  `validity__start_date` bigint(20) DEFAULT NULL,
  `validity__end_date` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_store_collection__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_store_collection`
--

LOCK TABLES `object_store_collection` WRITE;
/*!40000 ALTER TABLE `object_store_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_store_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_store_product`
--

DROP TABLE IF EXISTS `object_store_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_store_product` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `sku` varchar(190) DEFAULT NULL,
  `Color` varchar(190) DEFAULT NULL,
  `mainImage` int(11) DEFAULT NULL,
  `gallery__images` text DEFAULT NULL,
  `gallery__hotspots` longtext DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_store_product__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_store_product`
--

LOCK TABLES `object_store_product` WRITE;
/*!40000 ALTER TABLE `object_store_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_store_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_store_warehouse`
--

DROP TABLE IF EXISTS `object_store_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_store_warehouse` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(190) DEFAULT NULL,
  `location__longitude` double DEFAULT NULL,
  `location__latitude` double DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_store_warehouse__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_store_warehouse`
--

LOCK TABLES `object_store_warehouse` WRITE;
/*!40000 ALTER TABLE `object_store_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_store_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_url_slugs`
--

DROP TABLE IF EXISTS `object_url_slugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_url_slugs` (
  `objectId` int(11) unsigned NOT NULL DEFAULT 0,
  `classId` varchar(50) NOT NULL DEFAULT '0',
  `fieldname` varchar(70) NOT NULL DEFAULT '0',
  `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
  `ownername` varchar(70) NOT NULL DEFAULT '',
  `position` varchar(70) NOT NULL DEFAULT '0',
  `slug` varchar(765) NOT NULL,
  `siteId` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`slug`,`siteId`),
  KEY `objectId` (`objectId`),
  KEY `classId` (`classId`),
  KEY `fieldname` (`fieldname`),
  KEY `position` (`position`),
  KEY `ownertype` (`ownertype`),
  KEY `ownername` (`ownername`),
  KEY `slug` (`slug`),
  KEY `siteId` (`siteId`),
  KEY `fieldname_ownertype_position_objectId` (`fieldname`,`ownertype`,`position`,`objectId`),
  CONSTRAINT `fk_object_url_slugs__objectId` FOREIGN KEY (`objectId`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_url_slugs`
--

LOCK TABLES `object_url_slugs` WRITE;
/*!40000 ALTER TABLE `object_url_slugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_url_slugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `object_warehouse`
--

DROP TABLE IF EXISTS `object_warehouse`;
/*!50001 DROP VIEW IF EXISTS `object_warehouse`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_warehouse` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `name`,
  1 AS `location__longitude`,
  1 AS `location__latitude`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `objects`
--

DROP TABLE IF EXISTS `objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `objects` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned DEFAULT NULL,
  `type` enum('object','folder','variant') DEFAULT NULL,
  `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
  `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `index` int(11) unsigned DEFAULT 0,
  `published` tinyint(1) unsigned DEFAULT 1,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  `classId` varchar(50) DEFAULT NULL,
  `className` varchar(255) DEFAULT NULL,
  `childrenSortBy` enum('key','index') DEFAULT NULL,
  `childrenSortOrder` enum('ASC','DESC') DEFAULT NULL,
  `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fullpath` (`path`,`key`),
  KEY `key` (`key`),
  KEY `index` (`index`),
  KEY `published` (`published`),
  KEY `parentId` (`parentId`),
  KEY `type_path_classId` (`type`,`path`,`classId`),
  KEY `modificationDate` (`modificationDate`),
  KEY `classId` (`classId`),
  KEY `versionCount` (`versionCount`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objects`
--

LOCK TABLES `objects` WRITE;
/*!40000 ALTER TABLE `objects` DISABLE KEYS */;
INSERT INTO `objects` VALUES
(1,0,'folder','','/',999999,1,1759936097,1759936097,1,1,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `properties` (
  `cid` int(11) unsigned NOT NULL DEFAULT 0,
  `ctype` enum('document','asset','object') NOT NULL DEFAULT 'document',
  `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `name` varchar(190) NOT NULL DEFAULT '',
  `type` enum('text','document','asset','object','bool','select') DEFAULT NULL,
  `data` text DEFAULT NULL,
  `inheritable` tinyint(1) unsigned DEFAULT 1,
  PRIMARY KEY (`cid`,`ctype`,`name`),
  KEY `getall` (`cpath`,`ctype`,`inheritable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `properties`
--

LOCK TABLES `properties` WRITE;
/*!40000 ALTER TABLE `properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quantityvalue_units`
--

DROP TABLE IF EXISTS `quantityvalue_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quantityvalue_units` (
  `id` varchar(50) NOT NULL,
  `group` varchar(50) DEFAULT NULL,
  `abbreviation` varchar(20) DEFAULT NULL,
  `longname` varchar(250) DEFAULT NULL,
  `baseunit` varchar(50) DEFAULT NULL,
  `factor` double DEFAULT NULL,
  `conversionOffset` double DEFAULT NULL,
  `reference` varchar(50) DEFAULT NULL,
  `converter` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_baseunit` (`baseunit`),
  CONSTRAINT `fk_baseunit` FOREIGN KEY (`baseunit`) REFERENCES `quantityvalue_units` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quantityvalue_units`
--

LOCK TABLES `quantityvalue_units` WRITE;
/*!40000 ALTER TABLE `quantityvalue_units` DISABLE KEYS */;
INSERT INTO `quantityvalue_units` VALUES
('Grams','','gr','Grams',NULL,NULL,NULL,'',''),
('Kilograms','','kg','Kilograms',NULL,NULL,NULL,'',''),
('Tons','','ton','Tons',NULL,NULL,NULL,'',''),
('Units','','U','Units',NULL,NULL,NULL,'','');
/*!40000 ALTER TABLE `quantityvalue_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recyclebin`
--

DROP TABLE IF EXISTS `recyclebin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recyclebin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) DEFAULT NULL,
  `subtype` varchar(20) DEFAULT NULL,
  `path` varchar(765) DEFAULT NULL,
  `amount` int(3) DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `deletedby` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recyclebin_date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recyclebin`
--

LOCK TABLES `recyclebin` WRITE;
/*!40000 ALTER TABLE `recyclebin` DISABLE KEYS */;
INSERT INTO `recyclebin` VALUES
(1,'object','object','/prd1',1,1759949798,'admin');
/*!40000 ALTER TABLE `recyclebin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_tasks`
--

DROP TABLE IF EXISTS `schedule_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_tasks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) unsigned DEFAULT NULL,
  `ctype` enum('document','asset','object') DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `action` enum('publish','unpublish','delete','publish-version') DEFAULT NULL,
  `version` bigint(20) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT 0,
  `userId` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`),
  KEY `ctype` (`ctype`),
  KEY `active` (`active`),
  KEY `version` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_tasks`
--

LOCK TABLES `schedule_tasks` WRITE;
/*!40000 ALTER TABLE `schedule_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_backend_data`
--

DROP TABLE IF EXISTS `search_backend_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_backend_data` (
  `id` int(11) NOT NULL,
  `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
  `index` int(11) unsigned DEFAULT 0,
  `fullpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `maintype` varchar(8) NOT NULL DEFAULT '',
  `type` varchar(20) DEFAULT NULL,
  `subtype` varchar(190) DEFAULT NULL,
  `published` tinyint(1) unsigned DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) DEFAULT NULL,
  `userModification` int(11) DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  `properties` text DEFAULT NULL,
  PRIMARY KEY (`id`,`maintype`),
  KEY `key` (`key`),
  KEY `index` (`index`),
  KEY `fullpath` (`fullpath`),
  KEY `maintype` (`maintype`),
  KEY `type` (`type`),
  KEY `subtype` (`subtype`),
  KEY `published` (`published`),
  FULLTEXT KEY `fulltext` (`data`,`properties`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_backend_data`
--

LOCK TABLES `search_backend_data` WRITE;
/*!40000 ALTER TABLE `search_backend_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_backend_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings_store`
--

DROP TABLE IF EXISTS `settings_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_store` (
  `id` varchar(190) NOT NULL DEFAULT '',
  `scope` varchar(190) NOT NULL DEFAULT '',
  `data` longtext DEFAULT NULL,
  `type` enum('bool','int','float','string') NOT NULL DEFAULT 'string',
  PRIMARY KEY (`id`,`scope`),
  KEY `scope` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings_store`
--

LOCK TABLES `settings_store` WRITE;
/*!40000 ALTER TABLE `settings_store` DISABLE KEYS */;
INSERT INTO `settings_store` VALUES
('BUNDLE_INSTALLED__Pimcore\\Bundle\\SimpleBackendSearchBundle\\PimcoreSimpleBackendSearchBundle','pimcore','1','bool');
/*!40000 ALTER TABLE `settings_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mainDomain` varchar(255) DEFAULT NULL,
  `domains` text DEFAULT NULL,
  `rootId` int(11) unsigned DEFAULT NULL,
  `errorDocument` varchar(255) DEFAULT NULL,
  `localizedErrorDocuments` text DEFAULT NULL,
  `redirectToMainDomain` tinyint(1) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rootId` (`rootId`),
  CONSTRAINT `fk_sites_documents` FOREIGN KEY (`rootId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(10) unsigned DEFAULT NULL,
  `idPath` varchar(190) DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idPath_name` (`idPath`,`name`),
  KEY `idpath` (`idPath`),
  KEY `parentid` (`parentId`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags_assignment`
--

DROP TABLE IF EXISTS `tags_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags_assignment` (
  `tagid` int(10) unsigned NOT NULL DEFAULT 0,
  `cid` int(10) NOT NULL DEFAULT 0,
  `ctype` enum('document','asset','object') NOT NULL,
  PRIMARY KEY (`tagid`,`cid`,`ctype`),
  KEY `ctype` (`ctype`),
  KEY `ctype_cid` (`cid`,`ctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags_assignment`
--

LOCK TABLES `tags_assignment` WRITE;
/*!40000 ALTER TABLE `tags_assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmp_store`
--

DROP TABLE IF EXISTS `tmp_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmp_store` (
  `id` varchar(190) NOT NULL DEFAULT '',
  `tag` varchar(190) DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  `serialized` tinyint(2) NOT NULL DEFAULT 0,
  `date` int(11) unsigned DEFAULT NULL,
  `expiryDate` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tag` (`tag`),
  KEY `date` (`date`),
  KEY `expiryDate` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmp_store`
--

LOCK TABLES `tmp_store` WRITE;
/*!40000 ALTER TABLE `tmp_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `tmp_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations_admin`
--

DROP TABLE IF EXISTS `translations_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `translations_admin` (
  `key` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `type` varchar(10) DEFAULT NULL,
  `language` varchar(10) NOT NULL DEFAULT '',
  `text` text DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`key`,`language`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations_admin`
--

LOCK TABLES `translations_admin` WRITE;
/*!40000 ALTER TABLE `translations_admin` DISABLE KEYS */;
INSERT INTO `translations_admin` VALUES
('Alternatives','simple','ca','',1759949789,1759949789,2,2),
('Alternatives','simple','cs','',1759949789,1759949789,2,2),
('Alternatives','simple','de','',1759949789,1759949789,2,2),
('Alternatives','simple','en','',1759949789,1759949789,2,2),
('Alternatives','simple','es','',1759949789,1759949789,2,2),
('Alternatives','simple','fr','',1759949789,1759949789,2,2),
('Alternatives','simple','hu','',1759949789,1759949789,2,2),
('Alternatives','simple','it','',1759949789,1759949789,2,2),
('Alternatives','simple','ja','',1759949789,1759949789,2,2),
('Alternatives','simple','nl','',1759949789,1759949789,2,2),
('Alternatives','simple','pl','',1759949789,1759949789,2,2),
('Alternatives','simple','pt','',1759949789,1759949789,2,2),
('Alternatives','simple','ru','',1759949789,1759949789,2,2),
('Alternatives','simple','sk','',1759949789,1759949789,2,2),
('Alternatives','simple','sv','',1759949789,1759949789,2,2),
('Alternatives','simple','th','',1759949789,1759949789,2,2),
('Alternatives','simple','tr','',1759949789,1759949789,2,2),
('Alternatives','simple','uk','',1759949789,1759949789,2,2),
('Alternatives','simple','zh_Hans','',1759949789,1759949789,2,2),
('Availability','simple','ca','',1759949789,1759949789,2,2),
('Availability','simple','cs','',1759949789,1759949789,2,2),
('Availability','simple','de','',1759949789,1759949789,2,2),
('Availability','simple','en','',1759949789,1759949789,2,2),
('Availability','simple','es','',1759949789,1759949789,2,2),
('Availability','simple','fr','',1759949789,1759949789,2,2),
('Availability','simple','hu','',1759949789,1759949789,2,2),
('Availability','simple','it','',1759949789,1759949789,2,2),
('Availability','simple','ja','',1759949789,1759949789,2,2),
('Availability','simple','nl','',1759949789,1759949789,2,2),
('Availability','simple','pl','',1759949789,1759949789,2,2),
('Availability','simple','pt','',1759949789,1759949789,2,2),
('Availability','simple','ru','',1759949789,1759949789,2,2),
('Availability','simple','sk','',1759949789,1759949789,2,2),
('Availability','simple','sv','',1759949789,1759949789,2,2),
('Availability','simple','th','',1759949789,1759949789,2,2),
('Availability','simple','tr','',1759949789,1759949789,2,2),
('Availability','simple','uk','',1759949789,1759949789,2,2),
('Availability','simple','zh_Hans','',1759949789,1759949789,2,2),
('Azzurro','simple','ca','',1759949789,1759949789,2,2),
('Azzurro','simple','cs','',1759949789,1759949789,2,2),
('Azzurro','simple','de','',1759949789,1759949789,2,2),
('Azzurro','simple','en','',1759949789,1759949789,2,2),
('Azzurro','simple','es','',1759949789,1759949789,2,2),
('Azzurro','simple','fr','',1759949789,1759949789,2,2),
('Azzurro','simple','hu','',1759949789,1759949789,2,2),
('Azzurro','simple','it','',1759949789,1759949789,2,2),
('Azzurro','simple','ja','',1759949789,1759949789,2,2),
('Azzurro','simple','nl','',1759949789,1759949789,2,2),
('Azzurro','simple','pl','',1759949789,1759949789,2,2),
('Azzurro','simple','pt','',1759949789,1759949789,2,2),
('Azzurro','simple','ru','',1759949789,1759949789,2,2),
('Azzurro','simple','sk','',1759949789,1759949789,2,2),
('Azzurro','simple','sv','',1759949789,1759949789,2,2),
('Azzurro','simple','th','',1759949789,1759949789,2,2),
('Azzurro','simple','tr','',1759949789,1759949789,2,2),
('Azzurro','simple','uk','',1759949789,1759949789,2,2),
('Azzurro','simple','zh_Hans','',1759949789,1759949789,2,2),
('Belt','simple','ca','',1759951139,1759951139,2,2),
('Belt','simple','cs','',1759951139,1759951139,2,2),
('Belt','simple','de','',1759951139,1759951139,2,2),
('Belt','simple','en','',1759951139,1759951139,2,2),
('Belt','simple','es','',1759951139,1759951139,2,2),
('Belt','simple','fr','',1759951139,1759951139,2,2),
('Belt','simple','hu','',1759951139,1759951139,2,2),
('Belt','simple','it','',1759951139,1759951139,2,2),
('Belt','simple','ja','',1759951139,1759951139,2,2),
('Belt','simple','nl','',1759951139,1759951139,2,2),
('Belt','simple','pl','',1759951139,1759951139,2,2),
('Belt','simple','pt','',1759951139,1759951139,2,2),
('Belt','simple','ru','',1759951139,1759951139,2,2),
('Belt','simple','sk','',1759951139,1759951139,2,2),
('Belt','simple','sv','',1759951139,1759951139,2,2),
('Belt','simple','th','',1759951139,1759951139,2,2),
('Belt','simple','tr','',1759951139,1759951139,2,2),
('Belt','simple','uk','',1759951139,1759951139,2,2),
('Belt','simple','zh_Hans','',1759951139,1759951139,2,2),
('Belth Lenght','simple','ca','',1759951019,1759951019,2,2),
('Belth Lenght','simple','cs','',1759951019,1759951019,2,2),
('Belth Lenght','simple','de','',1759951019,1759951019,2,2),
('Belth Lenght','simple','en','',1759951019,1759951019,2,2),
('Belth Lenght','simple','es','',1759951019,1759951019,2,2),
('Belth Lenght','simple','fr','',1759951019,1759951019,2,2),
('Belth Lenght','simple','hu','',1759951019,1759951019,2,2),
('Belth Lenght','simple','it','',1759951019,1759951019,2,2),
('Belth Lenght','simple','ja','',1759951019,1759951019,2,2),
('Belth Lenght','simple','nl','',1759951019,1759951019,2,2),
('Belth Lenght','simple','pl','',1759951019,1759951019,2,2),
('Belth Lenght','simple','pt','',1759951019,1759951019,2,2),
('Belth Lenght','simple','ru','',1759951019,1759951019,2,2),
('Belth Lenght','simple','sk','',1759951019,1759951019,2,2),
('Belth Lenght','simple','sv','',1759951019,1759951019,2,2),
('Belth Lenght','simple','th','',1759951019,1759951019,2,2),
('Belth Lenght','simple','tr','',1759951019,1759951019,2,2),
('Belth Lenght','simple','uk','',1759951019,1759951019,2,2),
('Belth Lenght','simple','zh_Hans','',1759951019,1759951019,2,2),
('Blu','simple','ca','',1759949789,1759949789,2,2),
('Blu','simple','cs','',1759949789,1759949789,2,2),
('Blu','simple','de','',1759949789,1759949789,2,2),
('Blu','simple','en','',1759949789,1759949789,2,2),
('Blu','simple','es','',1759949789,1759949789,2,2),
('Blu','simple','fr','',1759949789,1759949789,2,2),
('Blu','simple','hu','',1759949789,1759949789,2,2),
('Blu','simple','it','',1759949789,1759949789,2,2),
('Blu','simple','ja','',1759949789,1759949789,2,2),
('Blu','simple','nl','',1759949789,1759949789,2,2),
('Blu','simple','pl','',1759949789,1759949789,2,2),
('Blu','simple','pt','',1759949789,1759949789,2,2),
('Blu','simple','ru','',1759949789,1759949789,2,2),
('Blu','simple','sk','',1759949789,1759949789,2,2),
('Blu','simple','sv','',1759949789,1759949789,2,2),
('Blu','simple','th','',1759949789,1759949789,2,2),
('Blu','simple','tr','',1759949789,1759949789,2,2),
('Blu','simple','uk','',1759949789,1759949789,2,2),
('Blu','simple','zh_Hans','',1759949789,1759949789,2,2),
('Box Specs','simple','ca','',1759951559,1759951559,2,2),
('Box Specs','simple','cs','',1759951559,1759951559,2,2),
('Box Specs','simple','de','',1759951559,1759951559,2,2),
('Box Specs','simple','en','',1759951559,1759951559,2,2),
('Box Specs','simple','es','',1759951559,1759951559,2,2),
('Box Specs','simple','fr','',1759951559,1759951559,2,2),
('Box Specs','simple','hu','',1759951559,1759951559,2,2),
('Box Specs','simple','it','',1759951559,1759951559,2,2),
('Box Specs','simple','ja','',1759951559,1759951559,2,2),
('Box Specs','simple','nl','',1759951559,1759951559,2,2),
('Box Specs','simple','pl','',1759951559,1759951559,2,2),
('Box Specs','simple','pt','',1759951559,1759951559,2,2),
('Box Specs','simple','ru','',1759951559,1759951559,2,2),
('Box Specs','simple','sk','',1759951559,1759951559,2,2),
('Box Specs','simple','sv','',1759951559,1759951559,2,2),
('Box Specs','simple','th','',1759951559,1759951559,2,2),
('Box Specs','simple','tr','',1759951559,1759951559,2,2),
('Box Specs','simple','uk','',1759951559,1759951559,2,2),
('Box Specs','simple','zh_Hans','',1759951559,1759951559,2,2),
('Box Type','simple','ca','',1759951559,1759951559,2,2),
('Box Type','simple','cs','',1759951559,1759951559,2,2),
('Box Type','simple','de','',1759951559,1759951559,2,2),
('Box Type','simple','en','',1759951559,1759951559,2,2),
('Box Type','simple','es','',1759951559,1759951559,2,2),
('Box Type','simple','fr','',1759951559,1759951559,2,2),
('Box Type','simple','hu','',1759951559,1759951559,2,2),
('Box Type','simple','it','',1759951559,1759951559,2,2),
('Box Type','simple','ja','',1759951559,1759951559,2,2),
('Box Type','simple','nl','',1759951559,1759951559,2,2),
('Box Type','simple','pl','',1759951559,1759951559,2,2),
('Box Type','simple','pt','',1759951559,1759951559,2,2),
('Box Type','simple','ru','',1759951559,1759951559,2,2),
('Box Type','simple','sk','',1759951559,1759951559,2,2),
('Box Type','simple','sv','',1759951559,1759951559,2,2),
('Box Type','simple','th','',1759951559,1759951559,2,2),
('Box Type','simple','tr','',1759951559,1759951559,2,2),
('Box Type','simple','uk','',1759951559,1759951559,2,2),
('Box Type','simple','zh_Hans','',1759951559,1759951559,2,2),
('Brand','simple','ca','Brand',1759937306,1759937306,2,2),
('Brand','simple','cs','Brand',1759937306,1759937306,2,2),
('Brand','simple','de','Brand',1759937306,1759937306,2,2),
('Brand','simple','en','Brand',1759937306,1759937306,2,2),
('Brand','simple','es','Brand',1759937306,1759937306,2,2),
('Brand','simple','fr','Brand',1759937306,1759937306,2,2),
('Brand','simple','hu','Brand',1759937306,1759937306,2,2),
('Brand','simple','it','Brand',1759937306,1759937306,2,2),
('Brand','simple','ja','Brand',1759937306,1759937306,2,2),
('Brand','simple','nl','Brand',1759937306,1759937306,2,2),
('Brand','simple','pl','Brand',1759937306,1759937306,2,2),
('Brand','simple','pt','Brand',1759937306,1759937306,2,2),
('Brand','simple','ru','Brand',1759937306,1759937306,2,2),
('Brand','simple','sk','Brand',1759937306,1759937306,2,2),
('Brand','simple','sv','Brand',1759937306,1759937306,2,2),
('Brand','simple','th','Brand',1759937306,1759937306,2,2),
('Brand','simple','tr','Brand',1759937306,1759937306,2,2),
('Brand','simple','uk','Brand',1759937306,1759937306,2,2),
('Brand','simple','zh_Hans','Brand',1759937306,1759937306,2,2),
('CSV Export','simple','ca','',1759949789,1759949789,2,2),
('CSV Export','simple','cs','',1759949789,1759949789,2,2),
('CSV Export','simple','de','',1759949789,1759949789,2,2),
('CSV Export','simple','en','',1759949789,1759949789,2,2),
('CSV Export','simple','es','',1759949789,1759949789,2,2),
('CSV Export','simple','fr','',1759949789,1759949789,2,2),
('CSV Export','simple','hu','',1759949789,1759949789,2,2),
('CSV Export','simple','it','',1759949789,1759949789,2,2),
('CSV Export','simple','ja','',1759949789,1759949789,2,2),
('CSV Export','simple','nl','',1759949789,1759949789,2,2),
('CSV Export','simple','pl','',1759949789,1759949789,2,2),
('CSV Export','simple','pt','',1759949789,1759949789,2,2),
('CSV Export','simple','ru','',1759949789,1759949789,2,2),
('CSV Export','simple','sk','',1759949789,1759949789,2,2),
('CSV Export','simple','sv','',1759949789,1759949789,2,2),
('CSV Export','simple','th','',1759949789,1759949789,2,2),
('CSV Export','simple','tr','',1759949789,1759949789,2,2),
('CSV Export','simple','uk','',1759949789,1759949789,2,2),
('CSV Export','simple','zh_Hans','',1759949789,1759949789,2,2),
('Collection','simple','ca','Collection',1759937306,1759937306,2,2),
('Collection','simple','cs','Collection',1759937306,1759937306,2,2),
('Collection','simple','de','Collection',1759937306,1759937306,2,2),
('Collection','simple','en','Collection',1759937306,1759937306,2,2),
('Collection','simple','es','Collection',1759937306,1759937306,2,2),
('Collection','simple','fr','Collection',1759937306,1759937306,2,2),
('Collection','simple','hu','Collection',1759937306,1759937306,2,2),
('Collection','simple','it','Collection',1759937306,1759937306,2,2),
('Collection','simple','ja','Collection',1759937306,1759937306,2,2),
('Collection','simple','nl','Collection',1759937306,1759937306,2,2),
('Collection','simple','pl','Collection',1759937306,1759937306,2,2),
('Collection','simple','pt','Collection',1759937306,1759937306,2,2),
('Collection','simple','ru','Collection',1759937306,1759937306,2,2),
('Collection','simple','sk','Collection',1759937306,1759937306,2,2),
('Collection','simple','sv','Collection',1759937306,1759937306,2,2),
('Collection','simple','th','Collection',1759937306,1759937306,2,2),
('Collection','simple','tr','Collection',1759937306,1759937306,2,2),
('Collection','simple','uk','Collection',1759937306,1759937306,2,2),
('Collection','simple','zh_Hans','Collection',1759937306,1759937306,2,2),
('Collections','simple','ca','',1759949789,1759949789,2,2),
('Collections','simple','cs','',1759949789,1759949789,2,2),
('Collections','simple','de','',1759949789,1759949789,2,2),
('Collections','simple','en','',1759949789,1759949789,2,2),
('Collections','simple','es','',1759949789,1759949789,2,2),
('Collections','simple','fr','',1759949789,1759949789,2,2),
('Collections','simple','hu','',1759949789,1759949789,2,2),
('Collections','simple','it','',1759949789,1759949789,2,2),
('Collections','simple','ja','',1759949789,1759949789,2,2),
('Collections','simple','nl','',1759949789,1759949789,2,2),
('Collections','simple','pl','',1759949789,1759949789,2,2),
('Collections','simple','pt','',1759949789,1759949789,2,2),
('Collections','simple','ru','',1759949789,1759949789,2,2),
('Collections','simple','sk','',1759949789,1759949789,2,2),
('Collections','simple','sv','',1759949789,1759949789,2,2),
('Collections','simple','th','',1759949789,1759949789,2,2),
('Collections','simple','tr','',1759949789,1759949789,2,2),
('Collections','simple','uk','',1759949789,1759949789,2,2),
('Collections','simple','zh_Hans','',1759949789,1759949789,2,2),
('Colletto','simple','ca','',1759951019,1759951019,2,2),
('Colletto','simple','cs','',1759951019,1759951019,2,2),
('Colletto','simple','de','',1759951019,1759951019,2,2),
('Colletto','simple','en','',1759951019,1759951019,2,2),
('Colletto','simple','es','',1759951019,1759951019,2,2),
('Colletto','simple','fr','',1759951019,1759951019,2,2),
('Colletto','simple','hu','',1759951019,1759951019,2,2),
('Colletto','simple','it','',1759951019,1759951019,2,2),
('Colletto','simple','ja','',1759951019,1759951019,2,2),
('Colletto','simple','nl','',1759951019,1759951019,2,2),
('Colletto','simple','pl','',1759951019,1759951019,2,2),
('Colletto','simple','pt','',1759951019,1759951019,2,2),
('Colletto','simple','ru','',1759951019,1759951019,2,2),
('Colletto','simple','sk','',1759951019,1759951019,2,2),
('Colletto','simple','sv','',1759951019,1759951019,2,2),
('Colletto','simple','th','',1759951019,1759951019,2,2),
('Colletto','simple','tr','',1759951019,1759951019,2,2),
('Colletto','simple','uk','',1759951019,1759951019,2,2),
('Colletto','simple','zh_Hans','',1759951019,1759951019,2,2),
('Color','simple','ca','',1759949789,1759949789,2,2),
('Color','simple','cs','',1759949789,1759949789,2,2),
('Color','simple','de','',1759949789,1759949789,2,2),
('Color','simple','en','',1759949789,1759949789,2,2),
('Color','simple','es','',1759949789,1759949789,2,2),
('Color','simple','fr','',1759949789,1759949789,2,2),
('Color','simple','hu','',1759949789,1759949789,2,2),
('Color','simple','it','',1759949789,1759949789,2,2),
('Color','simple','ja','',1759949789,1759949789,2,2),
('Color','simple','nl','',1759949789,1759949789,2,2),
('Color','simple','pl','',1759949789,1759949789,2,2),
('Color','simple','pt','',1759949789,1759949789,2,2),
('Color','simple','ru','',1759949789,1759949789,2,2),
('Color','simple','sk','',1759949789,1759949789,2,2),
('Color','simple','sv','',1759949789,1759949789,2,2),
('Color','simple','th','',1759949789,1759949789,2,2),
('Color','simple','tr','',1759949789,1759949789,2,2),
('Color','simple','uk','',1759949789,1759949789,2,2),
('Color','simple','zh_Hans','',1759949789,1759949789,2,2),
('Downloadables','simple','ca','',1759949789,1759949789,2,2),
('Downloadables','simple','cs','',1759949789,1759949789,2,2),
('Downloadables','simple','de','',1759949789,1759949789,2,2),
('Downloadables','simple','en','',1759949789,1759949789,2,2),
('Downloadables','simple','es','',1759949789,1759949789,2,2),
('Downloadables','simple','fr','',1759949789,1759949789,2,2),
('Downloadables','simple','hu','',1759949789,1759949789,2,2),
('Downloadables','simple','it','',1759949789,1759949789,2,2),
('Downloadables','simple','ja','',1759949789,1759949789,2,2),
('Downloadables','simple','nl','',1759949789,1759949789,2,2),
('Downloadables','simple','pl','',1759949789,1759949789,2,2),
('Downloadables','simple','pt','',1759949789,1759949789,2,2),
('Downloadables','simple','ru','',1759949789,1759949789,2,2),
('Downloadables','simple','sk','',1759949789,1759949789,2,2),
('Downloadables','simple','sv','',1759949789,1759949789,2,2),
('Downloadables','simple','th','',1759949789,1759949789,2,2),
('Downloadables','simple','tr','',1759949789,1759949789,2,2),
('Downloadables','simple','uk','',1759949789,1759949789,2,2),
('Downloadables','simple','zh_Hans','',1759949789,1759949789,2,2),
('English','simple','ca','',1759949789,1759949789,2,2),
('English','simple','cs','',1759949789,1759949789,2,2),
('English','simple','de','',1759949789,1759949789,2,2),
('English','simple','en','',1759949789,1759949789,2,2),
('English','simple','es','',1759949789,1759949789,2,2),
('English','simple','fr','',1759949789,1759949789,2,2),
('English','simple','hu','',1759949789,1759949789,2,2),
('English','simple','it','',1759949789,1759949789,2,2),
('English','simple','ja','',1759949789,1759949789,2,2),
('English','simple','nl','',1759949789,1759949789,2,2),
('English','simple','pl','',1759949789,1759949789,2,2),
('English','simple','pt','',1759949789,1759949789,2,2),
('English','simple','ru','',1759949789,1759949789,2,2),
('English','simple','sk','',1759949789,1759949789,2,2),
('English','simple','sv','',1759949789,1759949789,2,2),
('English','simple','th','',1759949789,1759949789,2,2),
('English','simple','tr','',1759949789,1759949789,2,2),
('English','simple','uk','',1759949789,1759949789,2,2),
('English','simple','zh_Hans','',1759949789,1759949789,2,2),
('Fabric','simple','ca','',1759951019,1759951019,2,2),
('Fabric','simple','cs','',1759951019,1759951019,2,2),
('Fabric','simple','de','',1759951019,1759951019,2,2),
('Fabric','simple','en','',1759951019,1759951019,2,2),
('Fabric','simple','es','',1759951019,1759951019,2,2),
('Fabric','simple','fr','',1759951019,1759951019,2,2),
('Fabric','simple','hu','',1759951019,1759951019,2,2),
('Fabric','simple','it','',1759951019,1759951019,2,2),
('Fabric','simple','ja','',1759951019,1759951019,2,2),
('Fabric','simple','nl','',1759951019,1759951019,2,2),
('Fabric','simple','pl','',1759951019,1759951019,2,2),
('Fabric','simple','pt','',1759951019,1759951019,2,2),
('Fabric','simple','ru','',1759951019,1759951019,2,2),
('Fabric','simple','sk','',1759951019,1759951019,2,2),
('Fabric','simple','sv','',1759951019,1759951019,2,2),
('Fabric','simple','th','',1759951019,1759951019,2,2),
('Fabric','simple','tr','',1759951019,1759951019,2,2),
('Fabric','simple','uk','',1759951019,1759951019,2,2),
('Fabric','simple','zh_Hans','',1759951019,1759951019,2,2),
('Files','simple','ca','',1759949789,1759949789,2,2),
('Files','simple','cs','',1759949789,1759949789,2,2),
('Files','simple','de','',1759949789,1759949789,2,2),
('Files','simple','en','',1759949789,1759949789,2,2),
('Files','simple','es','',1759949789,1759949789,2,2),
('Files','simple','fr','',1759949789,1759949789,2,2),
('Files','simple','hu','',1759949789,1759949789,2,2),
('Files','simple','it','',1759949789,1759949789,2,2),
('Files','simple','ja','',1759949789,1759949789,2,2),
('Files','simple','nl','',1759949789,1759949789,2,2),
('Files','simple','pl','',1759949789,1759949789,2,2),
('Files','simple','pt','',1759949789,1759949789,2,2),
('Files','simple','ru','',1759949789,1759949789,2,2),
('Files','simple','sk','',1759949789,1759949789,2,2),
('Files','simple','sv','',1759949789,1759949789,2,2),
('Files','simple','th','',1759949789,1759949789,2,2),
('Files','simple','tr','',1759949789,1759949789,2,2),
('Files','simple','uk','',1759949789,1759949789,2,2),
('Files','simple','zh_Hans','',1759949789,1759949789,2,2),
('French','simple','ca','',1759949789,1759949789,2,2),
('French','simple','cs','',1759949789,1759949789,2,2),
('French','simple','de','',1759949789,1759949789,2,2),
('French','simple','en','',1759949789,1759949789,2,2),
('French','simple','es','',1759949789,1759949789,2,2),
('French','simple','fr','',1759949789,1759949789,2,2),
('French','simple','hu','',1759949789,1759949789,2,2),
('French','simple','it','',1759949789,1759949789,2,2),
('French','simple','ja','',1759949789,1759949789,2,2),
('French','simple','nl','',1759949789,1759949789,2,2),
('French','simple','pl','',1759949789,1759949789,2,2),
('French','simple','pt','',1759949789,1759949789,2,2),
('French','simple','ru','',1759949789,1759949789,2,2),
('French','simple','sk','',1759949789,1759949789,2,2),
('French','simple','sv','',1759949789,1759949789,2,2),
('French','simple','th','',1759949789,1759949789,2,2),
('French','simple','tr','',1759949789,1759949789,2,2),
('French','simple','uk','',1759949789,1759949789,2,2),
('French','simple','zh_Hans','',1759949789,1759949789,2,2),
('Gallery','simple','ca','',1759949789,1759949789,2,2),
('Gallery','simple','cs','',1759949789,1759949789,2,2),
('Gallery','simple','de','',1759949789,1759949789,2,2),
('Gallery','simple','en','',1759949789,1759949789,2,2),
('Gallery','simple','es','',1759949789,1759949789,2,2),
('Gallery','simple','fr','',1759949789,1759949789,2,2),
('Gallery','simple','hu','',1759949789,1759949789,2,2),
('Gallery','simple','it','',1759949789,1759949789,2,2),
('Gallery','simple','ja','',1759949789,1759949789,2,2),
('Gallery','simple','nl','',1759949789,1759949789,2,2),
('Gallery','simple','pl','',1759949789,1759949789,2,2),
('Gallery','simple','pt','',1759949789,1759949789,2,2),
('Gallery','simple','ru','',1759949789,1759949789,2,2),
('Gallery','simple','sk','',1759949789,1759949789,2,2),
('Gallery','simple','sv','',1759949789,1759949789,2,2),
('Gallery','simple','th','',1759949789,1759949789,2,2),
('Gallery','simple','tr','',1759949789,1759949789,2,2),
('Gallery','simple','uk','',1759949789,1759949789,2,2),
('Gallery','simple','zh_Hans','',1759949789,1759949789,2,2),
('General Informations','simple','ca','',1759949789,1759949789,2,2),
('General Informations','simple','cs','',1759949789,1759949789,2,2),
('General Informations','simple','de','',1759949789,1759949789,2,2),
('General Informations','simple','en','',1759949789,1759949789,2,2),
('General Informations','simple','es','',1759949789,1759949789,2,2),
('General Informations','simple','fr','',1759949789,1759949789,2,2),
('General Informations','simple','hu','',1759949789,1759949789,2,2),
('General Informations','simple','it','',1759949789,1759949789,2,2),
('General Informations','simple','ja','',1759949789,1759949789,2,2),
('General Informations','simple','nl','',1759949789,1759949789,2,2),
('General Informations','simple','pl','',1759949789,1759949789,2,2),
('General Informations','simple','pt','',1759949789,1759949789,2,2),
('General Informations','simple','ru','',1759949789,1759949789,2,2),
('General Informations','simple','sk','',1759949789,1759949789,2,2),
('General Informations','simple','sv','',1759949789,1759949789,2,2),
('General Informations','simple','th','',1759949789,1759949789,2,2),
('General Informations','simple','tr','',1759949789,1759949789,2,2),
('General Informations','simple','uk','',1759949789,1759949789,2,2),
('General Informations','simple','zh_Hans','',1759949789,1759949789,2,2),
('German','simple','ca','',1759949789,1759949789,2,2),
('German','simple','cs','',1759949789,1759949789,2,2),
('German','simple','de','',1759949789,1759949789,2,2),
('German','simple','en','',1759949789,1759949789,2,2),
('German','simple','es','',1759949789,1759949789,2,2),
('German','simple','fr','',1759949789,1759949789,2,2),
('German','simple','hu','',1759949789,1759949789,2,2),
('German','simple','it','',1759949789,1759949789,2,2),
('German','simple','ja','',1759949789,1759949789,2,2),
('German','simple','nl','',1759949789,1759949789,2,2),
('German','simple','pl','',1759949789,1759949789,2,2),
('German','simple','pt','',1759949789,1759949789,2,2),
('German','simple','ru','',1759949789,1759949789,2,2),
('German','simple','sk','',1759949789,1759949789,2,2),
('German','simple','sv','',1759949789,1759949789,2,2),
('German','simple','th','',1759949789,1759949789,2,2),
('German','simple','tr','',1759949789,1759949789,2,2),
('German','simple','uk','',1759949789,1759949789,2,2),
('German','simple','zh_Hans','',1759949789,1759949789,2,2),
('Giallo','simple','ca','',1759949789,1759949789,2,2),
('Giallo','simple','cs','',1759949789,1759949789,2,2),
('Giallo','simple','de','',1759949789,1759949789,2,2),
('Giallo','simple','en','',1759949789,1759949789,2,2),
('Giallo','simple','es','',1759949789,1759949789,2,2),
('Giallo','simple','fr','',1759949789,1759949789,2,2),
('Giallo','simple','hu','',1759949789,1759949789,2,2),
('Giallo','simple','it','',1759949789,1759949789,2,2),
('Giallo','simple','ja','',1759949789,1759949789,2,2),
('Giallo','simple','nl','',1759949789,1759949789,2,2),
('Giallo','simple','pl','',1759949789,1759949789,2,2),
('Giallo','simple','pt','',1759949789,1759949789,2,2),
('Giallo','simple','ru','',1759949789,1759949789,2,2),
('Giallo','simple','sk','',1759949789,1759949789,2,2),
('Giallo','simple','sv','',1759949789,1759949789,2,2),
('Giallo','simple','th','',1759949789,1759949789,2,2),
('Giallo','simple','tr','',1759949789,1759949789,2,2),
('Giallo','simple','uk','',1759949789,1759949789,2,2),
('Giallo','simple','zh_Hans','',1759949789,1759949789,2,2),
('Grams','simple','ca','Grams',1759940982,1759940982,2,2),
('Grams','simple','cs','Grams',1759940982,1759940982,2,2),
('Grams','simple','de','Grams',1759940982,1759940982,2,2),
('Grams','simple','en','Grams',1759940982,1759940982,2,2),
('Grams','simple','es','Grams',1759940982,1759940982,2,2),
('Grams','simple','fr','Grams',1759940982,1759940982,2,2),
('Grams','simple','hu','Grams',1759940982,1759940982,2,2),
('Grams','simple','it','Grams',1759940982,1759940982,2,2),
('Grams','simple','ja','Grams',1759940982,1759940982,2,2),
('Grams','simple','nl','Grams',1759940982,1759940982,2,2),
('Grams','simple','pl','Grams',1759940982,1759940982,2,2),
('Grams','simple','pt','Grams',1759940982,1759940982,2,2),
('Grams','simple','ru','Grams',1759940982,1759940982,2,2),
('Grams','simple','sk','Grams',1759940982,1759940982,2,2),
('Grams','simple','sv','Grams',1759940982,1759940982,2,2),
('Grams','simple','th','Grams',1759940982,1759940982,2,2),
('Grams','simple','tr','Grams',1759940982,1759940982,2,2),
('Grams','simple','uk','Grams',1759940982,1759940982,2,2),
('Grams','simple','zh_Hans','Grams',1759940982,1759940982,2,2),
('Grigio','simple','ca','',1759949789,1759949789,2,2),
('Grigio','simple','cs','',1759949789,1759949789,2,2),
('Grigio','simple','de','',1759949789,1759949789,2,2),
('Grigio','simple','en','',1759949789,1759949789,2,2),
('Grigio','simple','es','',1759949789,1759949789,2,2),
('Grigio','simple','fr','',1759949789,1759949789,2,2),
('Grigio','simple','hu','',1759949789,1759949789,2,2),
('Grigio','simple','it','',1759949789,1759949789,2,2),
('Grigio','simple','ja','',1759949789,1759949789,2,2),
('Grigio','simple','nl','',1759949789,1759949789,2,2),
('Grigio','simple','pl','',1759949789,1759949789,2,2),
('Grigio','simple','pt','',1759949789,1759949789,2,2),
('Grigio','simple','ru','',1759949789,1759949789,2,2),
('Grigio','simple','sk','',1759949789,1759949789,2,2),
('Grigio','simple','sv','',1759949789,1759949789,2,2),
('Grigio','simple','th','',1759949789,1759949789,2,2),
('Grigio','simple','tr','',1759949789,1759949789,2,2),
('Grigio','simple','uk','',1759949789,1759949789,2,2),
('Grigio','simple','zh_Hans','',1759949789,1759949789,2,2),
('Kilograms','simple','ca','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','cs','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','de','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','en','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','es','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','fr','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','hu','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','it','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','ja','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','nl','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','pl','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','pt','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','ru','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','sk','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','sv','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','th','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','tr','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','uk','Kilograms',1759941005,1759941005,2,2),
('Kilograms','simple','zh_Hans','Kilograms',1759941005,1759941005,2,2),
('Main','simple','ca','',1759949789,1759949789,2,2),
('Main','simple','cs','',1759949789,1759949789,2,2),
('Main','simple','de','',1759949789,1759949789,2,2),
('Main','simple','en','',1759949789,1759949789,2,2),
('Main','simple','es','',1759949789,1759949789,2,2),
('Main','simple','fr','',1759949789,1759949789,2,2),
('Main','simple','hu','',1759949789,1759949789,2,2),
('Main','simple','it','',1759949789,1759949789,2,2),
('Main','simple','ja','',1759949789,1759949789,2,2),
('Main','simple','nl','',1759949789,1759949789,2,2),
('Main','simple','pl','',1759949789,1759949789,2,2),
('Main','simple','pt','',1759949789,1759949789,2,2),
('Main','simple','ru','',1759949789,1759949789,2,2),
('Main','simple','sk','',1759949789,1759949789,2,2),
('Main','simple','sv','',1759949789,1759949789,2,2),
('Main','simple','th','',1759949789,1759949789,2,2),
('Main','simple','tr','',1759949789,1759949789,2,2),
('Main','simple','uk','',1759949789,1759949789,2,2),
('Main','simple','zh_Hans','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','ca','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','cs','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','de','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','en','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','es','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','fr','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','hu','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','it','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','ja','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','nl','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','pl','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','pt','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','ru','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','sk','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','sv','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','th','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','tr','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','uk','',1759949789,1759949789,2,2),
('Main (Admin Mode)','simple','zh_Hans','',1759949789,1759949789,2,2),
('Main Image','simple','ca','',1759949789,1759949789,2,2),
('Main Image','simple','cs','',1759949789,1759949789,2,2),
('Main Image','simple','de','',1759949789,1759949789,2,2),
('Main Image','simple','en','',1759949789,1759949789,2,2),
('Main Image','simple','es','',1759949789,1759949789,2,2),
('Main Image','simple','fr','',1759949789,1759949789,2,2),
('Main Image','simple','hu','',1759949789,1759949789,2,2),
('Main Image','simple','it','',1759949789,1759949789,2,2),
('Main Image','simple','ja','',1759949789,1759949789,2,2),
('Main Image','simple','nl','',1759949789,1759949789,2,2),
('Main Image','simple','pl','',1759949789,1759949789,2,2),
('Main Image','simple','pt','',1759949789,1759949789,2,2),
('Main Image','simple','ru','',1759949789,1759949789,2,2),
('Main Image','simple','sk','',1759949789,1759949789,2,2),
('Main Image','simple','sv','',1759949789,1759949789,2,2),
('Main Image','simple','th','',1759949789,1759949789,2,2),
('Main Image','simple','tr','',1759949789,1759949789,2,2),
('Main Image','simple','uk','',1759949789,1759949789,2,2),
('Main Image','simple','zh_Hans','',1759949789,1759949789,2,2),
('Media','simple','ca','',1759949789,1759949789,2,2),
('Media','simple','cs','',1759949789,1759949789,2,2),
('Media','simple','de','',1759949789,1759949789,2,2),
('Media','simple','en','',1759949789,1759949789,2,2),
('Media','simple','es','',1759949789,1759949789,2,2),
('Media','simple','fr','',1759949789,1759949789,2,2),
('Media','simple','hu','',1759949789,1759949789,2,2),
('Media','simple','it','',1759949789,1759949789,2,2),
('Media','simple','ja','',1759949789,1759949789,2,2),
('Media','simple','nl','',1759949789,1759949789,2,2),
('Media','simple','pl','',1759949789,1759949789,2,2),
('Media','simple','pt','',1759949789,1759949789,2,2),
('Media','simple','ru','',1759949789,1759949789,2,2),
('Media','simple','sk','',1759949789,1759949789,2,2),
('Media','simple','sv','',1759949789,1759949789,2,2),
('Media','simple','th','',1759949789,1759949789,2,2),
('Media','simple','tr','',1759949789,1759949789,2,2),
('Media','simple','uk','',1759949789,1759949789,2,2),
('Media','simple','zh_Hans','',1759949789,1759949789,2,2),
('Nero','simple','ca','',1759949789,1759949789,2,2),
('Nero','simple','cs','',1759949789,1759949789,2,2),
('Nero','simple','de','',1759949789,1759949789,2,2),
('Nero','simple','en','',1759949789,1759949789,2,2),
('Nero','simple','es','',1759949789,1759949789,2,2),
('Nero','simple','fr','',1759949789,1759949789,2,2),
('Nero','simple','hu','',1759949789,1759949789,2,2),
('Nero','simple','it','',1759949789,1759949789,2,2),
('Nero','simple','ja','',1759949789,1759949789,2,2),
('Nero','simple','nl','',1759949789,1759949789,2,2),
('Nero','simple','pl','',1759949789,1759949789,2,2),
('Nero','simple','pt','',1759949789,1759949789,2,2),
('Nero','simple','ru','',1759949789,1759949789,2,2),
('Nero','simple','sk','',1759949789,1759949789,2,2),
('Nero','simple','sv','',1759949789,1759949789,2,2),
('Nero','simple','th','',1759949789,1759949789,2,2),
('Nero','simple','tr','',1759949789,1759949789,2,2),
('Nero','simple','uk','',1759949789,1759949789,2,2),
('Nero','simple','zh_Hans','',1759949789,1759949789,2,2),
('PHP Enum Name','simple','ca','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','cs','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','de','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','en','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','es','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','fr','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','hu','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','it','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','ja','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','nl','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','pl','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','pt','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','ru','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','sk','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','sv','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','th','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','tr','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','uk','',1759940693,1759940693,2,2),
('PHP Enum Name','simple','zh_Hans','',1759940693,1759940693,2,2),
('Pimcore\'s logotype','simple','de','',1759936899,1759936902,0,0),
('Pimcore\'s logotype','simple','en','',1759936899,1759936902,0,0),
('Pimcore\'s logotype','simple','fr','',1759936899,1759936902,0,0),
('Pimcore\'s logotype','simple','it','',1759936899,1759936902,0,0),
('Product','simple','ca','Product',1759938275,1759938275,2,2),
('Product','simple','cs','Product',1759938275,1759938275,2,2),
('Product','simple','de','Product',1759938275,1759938275,2,2),
('Product','simple','en','Product',1759938275,1759938275,2,2),
('Product','simple','es','Product',1759938275,1759938275,2,2),
('Product','simple','fr','Product',1759938275,1759938275,2,2),
('Product','simple','hu','Product',1759938275,1759938275,2,2),
('Product','simple','it','Product',1759938275,1759938275,2,2),
('Product','simple','ja','Product',1759938275,1759938275,2,2),
('Product','simple','nl','Product',1759938275,1759938275,2,2),
('Product','simple','pl','Product',1759938275,1759938275,2,2),
('Product','simple','pt','Product',1759938275,1759938275,2,2),
('Product','simple','ru','Product',1759938275,1759938275,2,2),
('Product','simple','sk','Product',1759938275,1759938275,2,2),
('Product','simple','sv','Product',1759938275,1759938275,2,2),
('Product','simple','th','Product',1759938275,1759938275,2,2),
('Product','simple','tr','Product',1759938275,1759938275,2,2),
('Product','simple','uk','Product',1759938275,1759938275,2,2),
('Product','simple','zh_Hans','Product',1759938275,1759938275,2,2),
('Product Information','simple','ca','',1759949789,1759949789,2,2),
('Product Information','simple','cs','',1759949789,1759949789,2,2),
('Product Information','simple','de','',1759949789,1759949789,2,2),
('Product Information','simple','en','',1759949789,1759949789,2,2),
('Product Information','simple','es','',1759949789,1759949789,2,2),
('Product Information','simple','fr','',1759949789,1759949789,2,2),
('Product Information','simple','hu','',1759949789,1759949789,2,2),
('Product Information','simple','it','',1759949789,1759949789,2,2),
('Product Information','simple','ja','',1759949789,1759949789,2,2),
('Product Information','simple','nl','',1759949789,1759949789,2,2),
('Product Information','simple','pl','',1759949789,1759949789,2,2),
('Product Information','simple','pt','',1759949789,1759949789,2,2),
('Product Information','simple','ru','',1759949789,1759949789,2,2),
('Product Information','simple','sk','',1759949789,1759949789,2,2),
('Product Information','simple','sv','',1759949789,1759949789,2,2),
('Product Information','simple','th','',1759949789,1759949789,2,2),
('Product Information','simple','tr','',1759949789,1759949789,2,2),
('Product Information','simple','uk','',1759949789,1759949789,2,2),
('Product Information','simple','zh_Hans','',1759949789,1759949789,2,2),
('Product Relations','simple','ca','',1759949789,1759949789,2,2),
('Product Relations','simple','cs','',1759949789,1759949789,2,2),
('Product Relations','simple','de','',1759949789,1759949789,2,2),
('Product Relations','simple','en','',1759949789,1759949789,2,2),
('Product Relations','simple','es','',1759949789,1759949789,2,2),
('Product Relations','simple','fr','',1759949789,1759949789,2,2),
('Product Relations','simple','hu','',1759949789,1759949789,2,2),
('Product Relations','simple','it','',1759949789,1759949789,2,2),
('Product Relations','simple','ja','',1759949789,1759949789,2,2),
('Product Relations','simple','nl','',1759949789,1759949789,2,2),
('Product Relations','simple','pl','',1759949789,1759949789,2,2),
('Product Relations','simple','pt','',1759949789,1759949789,2,2),
('Product Relations','simple','ru','',1759949789,1759949789,2,2),
('Product Relations','simple','sk','',1759949789,1759949789,2,2),
('Product Relations','simple','sv','',1759949789,1759949789,2,2),
('Product Relations','simple','th','',1759949789,1759949789,2,2),
('Product Relations','simple','tr','',1759949789,1759949789,2,2),
('Product Relations','simple','uk','',1759949789,1759949789,2,2),
('Product Relations','simple','zh_Hans','',1759949789,1759949789,2,2),
('Related','simple','ca','',1759949789,1759949789,2,2),
('Related','simple','cs','',1759949789,1759949789,2,2),
('Related','simple','de','',1759949789,1759949789,2,2),
('Related','simple','en','',1759949789,1759949789,2,2),
('Related','simple','es','',1759949789,1759949789,2,2),
('Related','simple','fr','',1759949789,1759949789,2,2),
('Related','simple','hu','',1759949789,1759949789,2,2),
('Related','simple','it','',1759949789,1759949789,2,2),
('Related','simple','ja','',1759949789,1759949789,2,2),
('Related','simple','nl','',1759949789,1759949789,2,2),
('Related','simple','pl','',1759949789,1759949789,2,2),
('Related','simple','pt','',1759949789,1759949789,2,2),
('Related','simple','ru','',1759949789,1759949789,2,2),
('Related','simple','sk','',1759949789,1759949789,2,2),
('Related','simple','sv','',1759949789,1759949789,2,2),
('Related','simple','th','',1759949789,1759949789,2,2),
('Related','simple','tr','',1759949789,1759949789,2,2),
('Related','simple','uk','',1759949789,1759949789,2,2),
('Related','simple','zh_Hans','',1759949789,1759949789,2,2),
('Rosso','simple','ca','',1759949789,1759949789,2,2),
('Rosso','simple','cs','',1759949789,1759949789,2,2),
('Rosso','simple','de','',1759949789,1759949789,2,2),
('Rosso','simple','en','',1759949789,1759949789,2,2),
('Rosso','simple','es','',1759949789,1759949789,2,2),
('Rosso','simple','fr','',1759949789,1759949789,2,2),
('Rosso','simple','hu','',1759949789,1759949789,2,2),
('Rosso','simple','it','',1759949789,1759949789,2,2),
('Rosso','simple','ja','',1759949789,1759949789,2,2),
('Rosso','simple','nl','',1759949789,1759949789,2,2),
('Rosso','simple','pl','',1759949789,1759949789,2,2),
('Rosso','simple','pt','',1759949789,1759949789,2,2),
('Rosso','simple','ru','',1759949789,1759949789,2,2),
('Rosso','simple','sk','',1759949789,1759949789,2,2),
('Rosso','simple','sv','',1759949789,1759949789,2,2),
('Rosso','simple','th','',1759949789,1759949789,2,2),
('Rosso','simple','tr','',1759949789,1759949789,2,2),
('Rosso','simple','uk','',1759949789,1759949789,2,2),
('Rosso','simple','zh_Hans','',1759949789,1759949789,2,2),
('Shipping','simple','ca','',1759949789,1759949789,2,2),
('Shipping','simple','cs','',1759949789,1759949789,2,2),
('Shipping','simple','de','',1759949789,1759949789,2,2),
('Shipping','simple','en','',1759949789,1759949789,2,2),
('Shipping','simple','es','',1759949789,1759949789,2,2),
('Shipping','simple','fr','',1759949789,1759949789,2,2),
('Shipping','simple','hu','',1759949789,1759949789,2,2),
('Shipping','simple','it','',1759949789,1759949789,2,2),
('Shipping','simple','ja','',1759949789,1759949789,2,2),
('Shipping','simple','nl','',1759949789,1759949789,2,2),
('Shipping','simple','pl','',1759949789,1759949789,2,2),
('Shipping','simple','pt','',1759949789,1759949789,2,2),
('Shipping','simple','ru','',1759949789,1759949789,2,2),
('Shipping','simple','sk','',1759949789,1759949789,2,2),
('Shipping','simple','sv','',1759949789,1759949789,2,2),
('Shipping','simple','th','',1759949789,1759949789,2,2),
('Shipping','simple','tr','',1759949789,1759949789,2,2),
('Shipping','simple','uk','',1759949789,1759949789,2,2),
('Shipping','simple','zh_Hans','',1759949789,1759949789,2,2),
('Shirt','simple','ca','',1759951139,1759951139,2,2),
('Shirt','simple','cs','',1759951139,1759951139,2,2),
('Shirt','simple','de','',1759951139,1759951139,2,2),
('Shirt','simple','en','',1759951139,1759951139,2,2),
('Shirt','simple','es','',1759951139,1759951139,2,2),
('Shirt','simple','fr','',1759951139,1759951139,2,2),
('Shirt','simple','hu','',1759951139,1759951139,2,2),
('Shirt','simple','it','',1759951139,1759951139,2,2),
('Shirt','simple','ja','',1759951139,1759951139,2,2),
('Shirt','simple','nl','',1759951139,1759951139,2,2),
('Shirt','simple','pl','',1759951139,1759951139,2,2),
('Shirt','simple','pt','',1759951139,1759951139,2,2),
('Shirt','simple','ru','',1759951139,1759951139,2,2),
('Shirt','simple','sk','',1759951139,1759951139,2,2),
('Shirt','simple','sv','',1759951139,1759951139,2,2),
('Shirt','simple','th','',1759951139,1759951139,2,2),
('Shirt','simple','tr','',1759951139,1759951139,2,2),
('Shirt','simple','uk','',1759951139,1759951139,2,2),
('Shirt','simple','zh_Hans','',1759951139,1759951139,2,2),
('Shirt - Size','simple','ca','',1759951019,1759951019,2,2),
('Shirt - Size','simple','cs','',1759951019,1759951019,2,2),
('Shirt - Size','simple','de','',1759951019,1759951019,2,2),
('Shirt - Size','simple','en','',1759951019,1759951019,2,2),
('Shirt - Size','simple','es','',1759951019,1759951019,2,2),
('Shirt - Size','simple','fr','',1759951019,1759951019,2,2),
('Shirt - Size','simple','hu','',1759951019,1759951019,2,2),
('Shirt - Size','simple','it','',1759951019,1759951019,2,2),
('Shirt - Size','simple','ja','',1759951019,1759951019,2,2),
('Shirt - Size','simple','nl','',1759951019,1759951019,2,2),
('Shirt - Size','simple','pl','',1759951019,1759951019,2,2),
('Shirt - Size','simple','pt','',1759951019,1759951019,2,2),
('Shirt - Size','simple','ru','',1759951019,1759951019,2,2),
('Shirt - Size','simple','sk','',1759951019,1759951019,2,2),
('Shirt - Size','simple','sv','',1759951019,1759951019,2,2),
('Shirt - Size','simple','th','',1759951019,1759951019,2,2),
('Shirt - Size','simple','tr','',1759951019,1759951019,2,2),
('Shirt - Size','simple','uk','',1759951019,1759951019,2,2),
('Shirt - Size','simple','zh_Hans','',1759951019,1759951019,2,2),
('Shoe - Size','simple','ca','',1759951019,1759951019,2,2),
('Shoe - Size','simple','cs','',1759951019,1759951019,2,2),
('Shoe - Size','simple','de','',1759951019,1759951019,2,2),
('Shoe - Size','simple','en','',1759951019,1759951019,2,2),
('Shoe - Size','simple','es','',1759951019,1759951019,2,2),
('Shoe - Size','simple','fr','',1759951019,1759951019,2,2),
('Shoe - Size','simple','hu','',1759951019,1759951019,2,2),
('Shoe - Size','simple','it','',1759951019,1759951019,2,2),
('Shoe - Size','simple','ja','',1759951019,1759951019,2,2),
('Shoe - Size','simple','nl','',1759951019,1759951019,2,2),
('Shoe - Size','simple','pl','',1759951019,1759951019,2,2),
('Shoe - Size','simple','pt','',1759951019,1759951019,2,2),
('Shoe - Size','simple','ru','',1759951019,1759951019,2,2),
('Shoe - Size','simple','sk','',1759951019,1759951019,2,2),
('Shoe - Size','simple','sv','',1759951019,1759951019,2,2),
('Shoe - Size','simple','th','',1759951019,1759951019,2,2),
('Shoe - Size','simple','tr','',1759951019,1759951019,2,2),
('Shoe - Size','simple','uk','',1759951019,1759951019,2,2),
('Shoe - Size','simple','zh_Hans','',1759951019,1759951019,2,2),
('Shoes','simple','ca','',1759951139,1759951139,2,2),
('Shoes','simple','cs','',1759951139,1759951139,2,2),
('Shoes','simple','de','',1759951139,1759951139,2,2),
('Shoes','simple','en','',1759951139,1759951139,2,2),
('Shoes','simple','es','',1759951139,1759951139,2,2),
('Shoes','simple','fr','',1759951139,1759951139,2,2),
('Shoes','simple','hu','',1759951139,1759951139,2,2),
('Shoes','simple','it','',1759951139,1759951139,2,2),
('Shoes','simple','ja','',1759951139,1759951139,2,2),
('Shoes','simple','nl','',1759951139,1759951139,2,2),
('Shoes','simple','pl','',1759951139,1759951139,2,2),
('Shoes','simple','pt','',1759951139,1759951139,2,2),
('Shoes','simple','ru','',1759951139,1759951139,2,2),
('Shoes','simple','sk','',1759951139,1759951139,2,2),
('Shoes','simple','sv','',1759951139,1759951139,2,2),
('Shoes','simple','th','',1759951139,1759951139,2,2),
('Shoes','simple','tr','',1759951139,1759951139,2,2),
('Shoes','simple','uk','',1759951139,1759951139,2,2),
('Shoes','simple','zh_Hans','',1759951139,1759951139,2,2),
('Sku','simple','ca','',1759949789,1759949789,2,2),
('Sku','simple','cs','',1759949789,1759949789,2,2),
('Sku','simple','de','',1759949789,1759949789,2,2),
('Sku','simple','en','',1759949789,1759949789,2,2),
('Sku','simple','es','',1759949789,1759949789,2,2),
('Sku','simple','fr','',1759949789,1759949789,2,2),
('Sku','simple','hu','',1759949789,1759949789,2,2),
('Sku','simple','it','',1759949789,1759949789,2,2),
('Sku','simple','ja','',1759949789,1759949789,2,2),
('Sku','simple','nl','',1759949789,1759949789,2,2),
('Sku','simple','pl','',1759949789,1759949789,2,2),
('Sku','simple','pt','',1759949789,1759949789,2,2),
('Sku','simple','ru','',1759949789,1759949789,2,2),
('Sku','simple','sk','',1759949789,1759949789,2,2),
('Sku','simple','sv','',1759949789,1759949789,2,2),
('Sku','simple','th','',1759949789,1759949789,2,2),
('Sku','simple','tr','',1759949789,1759949789,2,2),
('Sku','simple','uk','',1759949789,1759949789,2,2),
('Sku','simple','zh_Hans','',1759949789,1759949789,2,2),
('Specific Info','simple','ca','',1759949789,1759949789,2,2),
('Specific Info','simple','cs','',1759949789,1759949789,2,2),
('Specific Info','simple','de','',1759949789,1759949789,2,2),
('Specific Info','simple','en','',1759949789,1759949789,2,2),
('Specific Info','simple','es','',1759949789,1759949789,2,2),
('Specific Info','simple','fr','',1759949789,1759949789,2,2),
('Specific Info','simple','hu','',1759949789,1759949789,2,2),
('Specific Info','simple','it','',1759949789,1759949789,2,2),
('Specific Info','simple','ja','',1759949789,1759949789,2,2),
('Specific Info','simple','nl','',1759949789,1759949789,2,2),
('Specific Info','simple','pl','',1759949789,1759949789,2,2),
('Specific Info','simple','pt','',1759949789,1759949789,2,2),
('Specific Info','simple','ru','',1759949789,1759949789,2,2),
('Specific Info','simple','sk','',1759949789,1759949789,2,2),
('Specific Info','simple','sv','',1759949789,1759949789,2,2),
('Specific Info','simple','th','',1759949789,1759949789,2,2),
('Specific Info','simple','tr','',1759949789,1759949789,2,2),
('Specific Info','simple','uk','',1759949789,1759949789,2,2),
('Specific Info','simple','zh_Hans','',1759949789,1759949789,2,2),
('TShirt - Size','simple','ca','',1759951019,1759951019,2,2),
('TShirt - Size','simple','cs','',1759951019,1759951019,2,2),
('TShirt - Size','simple','de','',1759951019,1759951019,2,2),
('TShirt - Size','simple','en','',1759951019,1759951019,2,2),
('TShirt - Size','simple','es','',1759951019,1759951019,2,2),
('TShirt - Size','simple','fr','',1759951019,1759951019,2,2),
('TShirt - Size','simple','hu','',1759951019,1759951019,2,2),
('TShirt - Size','simple','it','',1759951019,1759951019,2,2),
('TShirt - Size','simple','ja','',1759951019,1759951019,2,2),
('TShirt - Size','simple','nl','',1759951019,1759951019,2,2),
('TShirt - Size','simple','pl','',1759951019,1759951019,2,2),
('TShirt - Size','simple','pt','',1759951019,1759951019,2,2),
('TShirt - Size','simple','ru','',1759951019,1759951019,2,2),
('TShirt - Size','simple','sk','',1759951019,1759951019,2,2),
('TShirt - Size','simple','sv','',1759951019,1759951019,2,2),
('TShirt - Size','simple','th','',1759951019,1759951019,2,2),
('TShirt - Size','simple','tr','',1759951019,1759951019,2,2),
('TShirt - Size','simple','uk','',1759951019,1759951019,2,2),
('TShirt - Size','simple','zh_Hans','',1759951019,1759951019,2,2),
('Throuser','simple','ca','',1759951139,1759951139,2,2),
('Throuser','simple','cs','',1759951139,1759951139,2,2),
('Throuser','simple','de','',1759951139,1759951139,2,2),
('Throuser','simple','en','',1759951139,1759951139,2,2),
('Throuser','simple','es','',1759951139,1759951139,2,2),
('Throuser','simple','fr','',1759951139,1759951139,2,2),
('Throuser','simple','hu','',1759951139,1759951139,2,2),
('Throuser','simple','it','',1759951139,1759951139,2,2),
('Throuser','simple','ja','',1759951139,1759951139,2,2),
('Throuser','simple','nl','',1759951139,1759951139,2,2),
('Throuser','simple','pl','',1759951139,1759951139,2,2),
('Throuser','simple','pt','',1759951139,1759951139,2,2),
('Throuser','simple','ru','',1759951139,1759951139,2,2),
('Throuser','simple','sk','',1759951139,1759951139,2,2),
('Throuser','simple','sv','',1759951139,1759951139,2,2),
('Throuser','simple','th','',1759951139,1759951139,2,2),
('Throuser','simple','tr','',1759951139,1759951139,2,2),
('Throuser','simple','uk','',1759951139,1759951139,2,2),
('Throuser','simple','zh_Hans','',1759951139,1759951139,2,2),
('Throuser - Size','simple','ca','',1759951019,1759951019,2,2),
('Throuser - Size','simple','cs','',1759951019,1759951019,2,2),
('Throuser - Size','simple','de','',1759951019,1759951019,2,2),
('Throuser - Size','simple','en','',1759951019,1759951019,2,2),
('Throuser - Size','simple','es','',1759951019,1759951019,2,2),
('Throuser - Size','simple','fr','',1759951019,1759951019,2,2),
('Throuser - Size','simple','hu','',1759951019,1759951019,2,2),
('Throuser - Size','simple','it','',1759951019,1759951019,2,2),
('Throuser - Size','simple','ja','',1759951019,1759951019,2,2),
('Throuser - Size','simple','nl','',1759951019,1759951019,2,2),
('Throuser - Size','simple','pl','',1759951019,1759951019,2,2),
('Throuser - Size','simple','pt','',1759951019,1759951019,2,2),
('Throuser - Size','simple','ru','',1759951019,1759951019,2,2),
('Throuser - Size','simple','sk','',1759951019,1759951019,2,2),
('Throuser - Size','simple','sv','',1759951019,1759951019,2,2),
('Throuser - Size','simple','th','',1759951019,1759951019,2,2),
('Throuser - Size','simple','tr','',1759951019,1759951019,2,2),
('Throuser - Size','simple','uk','',1759951019,1759951019,2,2),
('Throuser - Size','simple','zh_Hans','',1759951019,1759951019,2,2),
('Tons','simple','ca','Tons',1759941021,1759941021,2,2),
('Tons','simple','cs','Tons',1759941021,1759941021,2,2),
('Tons','simple','de','Tons',1759941021,1759941021,2,2),
('Tons','simple','en','Tons',1759941021,1759941021,2,2),
('Tons','simple','es','Tons',1759941021,1759941021,2,2),
('Tons','simple','fr','Tons',1759941021,1759941021,2,2),
('Tons','simple','hu','Tons',1759941021,1759941021,2,2),
('Tons','simple','it','Tons',1759941021,1759941021,2,2),
('Tons','simple','ja','Tons',1759941021,1759941021,2,2),
('Tons','simple','nl','Tons',1759941021,1759941021,2,2),
('Tons','simple','pl','Tons',1759941021,1759941021,2,2),
('Tons','simple','pt','Tons',1759941021,1759941021,2,2),
('Tons','simple','ru','Tons',1759941021,1759941021,2,2),
('Tons','simple','sk','Tons',1759941021,1759941021,2,2),
('Tons','simple','sv','Tons',1759941021,1759941021,2,2),
('Tons','simple','th','Tons',1759941021,1759941021,2,2),
('Tons','simple','tr','Tons',1759941021,1759941021,2,2),
('Tons','simple','uk','Tons',1759941021,1759941021,2,2),
('Tons','simple','zh_Hans','Tons',1759941021,1759941021,2,2),
('Tshirt','simple','ca','',1759951139,1759951139,2,2),
('Tshirt','simple','cs','',1759951139,1759951139,2,2),
('Tshirt','simple','de','',1759951139,1759951139,2,2),
('Tshirt','simple','en','',1759951139,1759951139,2,2),
('Tshirt','simple','es','',1759951139,1759951139,2,2),
('Tshirt','simple','fr','',1759951139,1759951139,2,2),
('Tshirt','simple','hu','',1759951139,1759951139,2,2),
('Tshirt','simple','it','',1759951139,1759951139,2,2),
('Tshirt','simple','ja','',1759951139,1759951139,2,2),
('Tshirt','simple','nl','',1759951139,1759951139,2,2),
('Tshirt','simple','pl','',1759951139,1759951139,2,2),
('Tshirt','simple','pt','',1759951139,1759951139,2,2),
('Tshirt','simple','ru','',1759951139,1759951139,2,2),
('Tshirt','simple','sk','',1759951139,1759951139,2,2),
('Tshirt','simple','sv','',1759951139,1759951139,2,2),
('Tshirt','simple','th','',1759951139,1759951139,2,2),
('Tshirt','simple','tr','',1759951139,1759951139,2,2),
('Tshirt','simple','uk','',1759951139,1759951139,2,2),
('Tshirt','simple','zh_Hans','',1759951139,1759951139,2,2),
('U','simple','ca','U',1759941039,1759941039,2,2),
('U','simple','cs','U',1759941039,1759941039,2,2),
('U','simple','de','U',1759941039,1759941039,2,2),
('U','simple','en','U',1759941039,1759941039,2,2),
('U','simple','es','U',1759941039,1759941039,2,2),
('U','simple','fr','U',1759941039,1759941039,2,2),
('U','simple','hu','U',1759941039,1759941039,2,2),
('U','simple','it','U',1759941039,1759941039,2,2),
('U','simple','ja','U',1759941039,1759941039,2,2),
('U','simple','nl','U',1759941039,1759941039,2,2),
('U','simple','pl','U',1759941039,1759941039,2,2),
('U','simple','pt','U',1759941039,1759941039,2,2),
('U','simple','ru','U',1759941039,1759941039,2,2),
('U','simple','sk','U',1759941039,1759941039,2,2),
('U','simple','sv','U',1759941039,1759941039,2,2),
('U','simple','th','U',1759941039,1759941039,2,2),
('U','simple','tr','U',1759941039,1759941039,2,2),
('U','simple','uk','U',1759941039,1759941039,2,2),
('U','simple','zh_Hans','U',1759941039,1759941039,2,2),
('Units','simple','ca','Units',1759941039,1759941039,2,2),
('Units','simple','cs','Units',1759941039,1759941039,2,2),
('Units','simple','de','Units',1759941039,1759941039,2,2),
('Units','simple','en','Units',1759941039,1759941039,2,2),
('Units','simple','es','Units',1759941039,1759941039,2,2),
('Units','simple','fr','Units',1759941039,1759941039,2,2),
('Units','simple','hu','Units',1759941039,1759941039,2,2),
('Units','simple','it','Units',1759941039,1759941039,2,2),
('Units','simple','ja','Units',1759941039,1759941039,2,2),
('Units','simple','nl','Units',1759941039,1759941039,2,2),
('Units','simple','pl','Units',1759941039,1759941039,2,2),
('Units','simple','pt','Units',1759941039,1759941039,2,2),
('Units','simple','ru','Units',1759941039,1759941039,2,2),
('Units','simple','sk','Units',1759941039,1759941039,2,2),
('Units','simple','sv','Units',1759941039,1759941039,2,2),
('Units','simple','th','Units',1759941039,1759941039,2,2),
('Units','simple','tr','Units',1759941039,1759941039,2,2),
('Units','simple','uk','Units',1759941039,1759941039,2,2),
('Units','simple','zh_Hans','Units',1759941039,1759941039,2,2),
('Verde','simple','ca','',1759949789,1759949789,2,2),
('Verde','simple','cs','',1759949789,1759949789,2,2),
('Verde','simple','de','',1759949789,1759949789,2,2),
('Verde','simple','en','',1759949789,1759949789,2,2),
('Verde','simple','es','',1759949789,1759949789,2,2),
('Verde','simple','fr','',1759949789,1759949789,2,2),
('Verde','simple','hu','',1759949789,1759949789,2,2),
('Verde','simple','it','',1759949789,1759949789,2,2),
('Verde','simple','ja','',1759949789,1759949789,2,2),
('Verde','simple','nl','',1759949789,1759949789,2,2),
('Verde','simple','pl','',1759949789,1759949789,2,2),
('Verde','simple','pt','',1759949789,1759949789,2,2),
('Verde','simple','ru','',1759949789,1759949789,2,2),
('Verde','simple','sk','',1759949789,1759949789,2,2),
('Verde','simple','sv','',1759949789,1759949789,2,2),
('Verde','simple','th','',1759949789,1759949789,2,2),
('Verde','simple','tr','',1759949789,1759949789,2,2),
('Verde','simple','uk','',1759949789,1759949789,2,2),
('Verde','simple','zh_Hans','',1759949789,1759949789,2,2),
('Warehouse','simple','ca','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','cs','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','de','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','en','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','es','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','fr','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','hu','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','it','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','ja','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','nl','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','pl','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','pt','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','ru','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','sk','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','sv','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','th','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','tr','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','uk','Warehouse',1759937532,1759937532,2,2),
('Warehouse','simple','zh_Hans','Warehouse',1759937532,1759937532,2,2),
('Warehouse Availability','simple','ca','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','cs','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','de','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','en','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','es','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','fr','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','hu','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','it','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','ja','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','nl','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','pl','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','pt','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','ru','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','sk','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','sv','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','th','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','tr','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','uk','',1759949789,1759949789,2,2),
('Warehouse Availability','simple','zh_Hans','',1759949789,1759949789,2,2),
('XLSX Export','simple','ca','',1759949789,1759949789,2,2),
('XLSX Export','simple','cs','',1759949789,1759949789,2,2),
('XLSX Export','simple','de','',1759949789,1759949789,2,2),
('XLSX Export','simple','en','',1759949789,1759949789,2,2),
('XLSX Export','simple','es','',1759949789,1759949789,2,2),
('XLSX Export','simple','fr','',1759949789,1759949789,2,2),
('XLSX Export','simple','hu','',1759949789,1759949789,2,2),
('XLSX Export','simple','it','',1759949789,1759949789,2,2),
('XLSX Export','simple','ja','',1759949789,1759949789,2,2),
('XLSX Export','simple','nl','',1759949789,1759949789,2,2),
('XLSX Export','simple','pl','',1759949789,1759949789,2,2),
('XLSX Export','simple','pt','',1759949789,1759949789,2,2),
('XLSX Export','simple','ru','',1759949789,1759949789,2,2),
('XLSX Export','simple','sk','',1759949789,1759949789,2,2),
('XLSX Export','simple','sv','',1759949789,1759949789,2,2),
('XLSX Export','simple','th','',1759949789,1759949789,2,2),
('XLSX Export','simple','tr','',1759949789,1759949789,2,2),
('XLSX Export','simple','uk','',1759949789,1759949789,2,2),
('XLSX Export','simple','zh_Hans','',1759949789,1759949789,2,2),
('bottom','simple','ca','',1759937351,1759937351,2,2),
('bottom','simple','cs','',1759937351,1759937351,2,2),
('bottom','simple','de','',1759937351,1759937351,2,2),
('bottom','simple','en','',1759937351,1759937351,2,2),
('bottom','simple','es','',1759937351,1759937351,2,2),
('bottom','simple','fr','',1759937351,1759937351,2,2),
('bottom','simple','hu','',1759937351,1759937351,2,2),
('bottom','simple','it','',1759937351,1759937351,2,2),
('bottom','simple','ja','',1759937351,1759937351,2,2),
('bottom','simple','nl','',1759937351,1759937351,2,2),
('bottom','simple','pl','',1759937351,1759937351,2,2),
('bottom','simple','pt','',1759937351,1759937351,2,2),
('bottom','simple','ru','',1759937351,1759937351,2,2),
('bottom','simple','sk','',1759937351,1759937351,2,2),
('bottom','simple','sv','',1759937351,1759937351,2,2),
('bottom','simple','th','',1759937351,1759937351,2,2),
('bottom','simple','tr','',1759937351,1759937351,2,2),
('bottom','simple','uk','',1759937351,1759937351,2,2),
('bottom','simple','zh_Hans','',1759937351,1759937351,2,2),
('boxDepth','simple','ca','',1759951529,1759951529,2,2),
('boxDepth','simple','cs','',1759951529,1759951529,2,2),
('boxDepth','simple','de','',1759951529,1759951529,2,2),
('boxDepth','simple','en','',1759951529,1759951529,2,2),
('boxDepth','simple','es','',1759951529,1759951529,2,2),
('boxDepth','simple','fr','',1759951529,1759951529,2,2),
('boxDepth','simple','hu','',1759951529,1759951529,2,2),
('boxDepth','simple','it','',1759951529,1759951529,2,2),
('boxDepth','simple','ja','',1759951529,1759951529,2,2),
('boxDepth','simple','nl','',1759951529,1759951529,2,2),
('boxDepth','simple','pl','',1759951529,1759951529,2,2),
('boxDepth','simple','pt','',1759951529,1759951529,2,2),
('boxDepth','simple','ru','',1759951529,1759951529,2,2),
('boxDepth','simple','sk','',1759951529,1759951529,2,2),
('boxDepth','simple','sv','',1759951529,1759951529,2,2),
('boxDepth','simple','th','',1759951529,1759951529,2,2),
('boxDepth','simple','tr','',1759951529,1759951529,2,2),
('boxDepth','simple','uk','',1759951529,1759951529,2,2),
('boxDepth','simple','zh_Hans','',1759951529,1759951529,2,2),
('boxHeight','simple','ca','',1759951529,1759951529,2,2),
('boxHeight','simple','cs','',1759951529,1759951529,2,2),
('boxHeight','simple','de','',1759951529,1759951529,2,2),
('boxHeight','simple','en','',1759951529,1759951529,2,2),
('boxHeight','simple','es','',1759951529,1759951529,2,2),
('boxHeight','simple','fr','',1759951529,1759951529,2,2),
('boxHeight','simple','hu','',1759951529,1759951529,2,2),
('boxHeight','simple','it','',1759951529,1759951529,2,2),
('boxHeight','simple','ja','',1759951529,1759951529,2,2),
('boxHeight','simple','nl','',1759951529,1759951529,2,2),
('boxHeight','simple','pl','',1759951529,1759951529,2,2),
('boxHeight','simple','pt','',1759951529,1759951529,2,2),
('boxHeight','simple','ru','',1759951529,1759951529,2,2),
('boxHeight','simple','sk','',1759951529,1759951529,2,2),
('boxHeight','simple','sv','',1759951529,1759951529,2,2),
('boxHeight','simple','th','',1759951529,1759951529,2,2),
('boxHeight','simple','tr','',1759951529,1759951529,2,2),
('boxHeight','simple','uk','',1759951529,1759951529,2,2),
('boxHeight','simple','zh_Hans','',1759951529,1759951529,2,2),
('boxMaterial','simple','ca','',1759951529,1759951529,2,2),
('boxMaterial','simple','cs','',1759951529,1759951529,2,2),
('boxMaterial','simple','de','',1759951529,1759951529,2,2),
('boxMaterial','simple','en','',1759951529,1759951529,2,2),
('boxMaterial','simple','es','',1759951529,1759951529,2,2),
('boxMaterial','simple','fr','',1759951529,1759951529,2,2),
('boxMaterial','simple','hu','',1759951529,1759951529,2,2),
('boxMaterial','simple','it','',1759951529,1759951529,2,2),
('boxMaterial','simple','ja','',1759951529,1759951529,2,2),
('boxMaterial','simple','nl','',1759951529,1759951529,2,2),
('boxMaterial','simple','pl','',1759951529,1759951529,2,2),
('boxMaterial','simple','pt','',1759951529,1759951529,2,2),
('boxMaterial','simple','ru','',1759951529,1759951529,2,2),
('boxMaterial','simple','sk','',1759951529,1759951529,2,2),
('boxMaterial','simple','sv','',1759951529,1759951529,2,2),
('boxMaterial','simple','th','',1759951529,1759951529,2,2),
('boxMaterial','simple','tr','',1759951529,1759951529,2,2),
('boxMaterial','simple','uk','',1759951529,1759951529,2,2),
('boxMaterial','simple','zh_Hans','',1759951529,1759951529,2,2),
('boxWeight','simple','ca','',1759951529,1759951529,2,2),
('boxWeight','simple','cs','',1759951529,1759951529,2,2),
('boxWeight','simple','de','',1759951529,1759951529,2,2),
('boxWeight','simple','en','',1759951529,1759951529,2,2),
('boxWeight','simple','es','',1759951529,1759951529,2,2),
('boxWeight','simple','fr','',1759951529,1759951529,2,2),
('boxWeight','simple','hu','',1759951529,1759951529,2,2),
('boxWeight','simple','it','',1759951529,1759951529,2,2),
('boxWeight','simple','ja','',1759951529,1759951529,2,2),
('boxWeight','simple','nl','',1759951529,1759951529,2,2),
('boxWeight','simple','pl','',1759951529,1759951529,2,2),
('boxWeight','simple','pt','',1759951529,1759951529,2,2),
('boxWeight','simple','ru','',1759951529,1759951529,2,2),
('boxWeight','simple','sk','',1759951529,1759951529,2,2),
('boxWeight','simple','sv','',1759951529,1759951529,2,2),
('boxWeight','simple','th','',1759951529,1759951529,2,2),
('boxWeight','simple','tr','',1759951529,1759951529,2,2),
('boxWeight','simple','uk','',1759951529,1759951529,2,2),
('boxWeight','simple','zh_Hans','',1759951529,1759951529,2,2),
('boxWidth','simple','ca','',1759951529,1759951529,2,2),
('boxWidth','simple','cs','',1759951529,1759951529,2,2),
('boxWidth','simple','de','',1759951529,1759951529,2,2),
('boxWidth','simple','en','',1759951529,1759951529,2,2),
('boxWidth','simple','es','',1759951529,1759951529,2,2),
('boxWidth','simple','fr','',1759951529,1759951529,2,2),
('boxWidth','simple','hu','',1759951529,1759951529,2,2),
('boxWidth','simple','it','',1759951529,1759951529,2,2),
('boxWidth','simple','ja','',1759951529,1759951529,2,2),
('boxWidth','simple','nl','',1759951529,1759951529,2,2),
('boxWidth','simple','pl','',1759951529,1759951529,2,2),
('boxWidth','simple','pt','',1759951529,1759951529,2,2),
('boxWidth','simple','ru','',1759951529,1759951529,2,2),
('boxWidth','simple','sk','',1759951529,1759951529,2,2),
('boxWidth','simple','sv','',1759951529,1759951529,2,2),
('boxWidth','simple','th','',1759951529,1759951529,2,2),
('boxWidth','simple','tr','',1759951529,1759951529,2,2),
('boxWidth','simple','uk','',1759951529,1759951529,2,2),
('boxWidth','simple','zh_Hans','',1759951529,1759951529,2,2),
('clear','simple','ca','',1759936646,1759936646,2,2),
('clear','simple','cs','',1759936646,1759936646,2,2),
('clear','simple','de','',1759936646,1759936646,2,2),
('clear','simple','en','',1759936646,1759936646,2,2),
('clear','simple','es','',1759936646,1759936646,2,2),
('clear','simple','fr','',1759936646,1759936646,2,2),
('clear','simple','hu','',1759936646,1759936646,2,2),
('clear','simple','it','',1759936646,1759936646,2,2),
('clear','simple','ja','',1759936646,1759936646,2,2),
('clear','simple','nl','',1759936646,1759936646,2,2),
('clear','simple','pl','',1759936646,1759936646,2,2),
('clear','simple','pt','',1759936646,1759936646,2,2),
('clear','simple','ru','',1759936646,1759936646,2,2),
('clear','simple','sk','',1759936646,1759936646,2,2),
('clear','simple','sv','',1759936646,1759936646,2,2),
('clear','simple','th','',1759936646,1759936646,2,2),
('clear','simple','tr','',1759936646,1759936646,2,2),
('clear','simple','uk','',1759936646,1759936646,2,2),
('clear','simple','zh_Hans','',1759936646,1759936646,2,2),
('down','simple','ca','',1759939307,1759939307,2,2),
('down','simple','cs','',1759939307,1759939307,2,2),
('down','simple','de','',1759939307,1759939307,2,2),
('down','simple','en','',1759939307,1759939307,2,2),
('down','simple','es','',1759939307,1759939307,2,2),
('down','simple','fr','',1759939307,1759939307,2,2),
('down','simple','hu','',1759939307,1759939307,2,2),
('down','simple','it','',1759939307,1759939307,2,2),
('down','simple','ja','',1759939307,1759939307,2,2),
('down','simple','nl','',1759939307,1759939307,2,2),
('down','simple','pl','',1759939307,1759939307,2,2),
('down','simple','pt','',1759939307,1759939307,2,2),
('down','simple','ru','',1759939307,1759939307,2,2),
('down','simple','sk','',1759939307,1759939307,2,2),
('down','simple','sv','',1759939307,1759939307,2,2),
('down','simple','th','',1759939307,1759939307,2,2),
('down','simple','tr','',1759939307,1759939307,2,2),
('down','simple','uk','',1759939307,1759939307,2,2),
('down','simple','zh_Hans','',1759939307,1759939307,2,2),
('global','simple','ca','',1759937441,1759937441,2,2),
('global','simple','cs','',1759937441,1759937441,2,2),
('global','simple','de','',1759937441,1759937441,2,2),
('global','simple','en','',1759937441,1759937441,2,2),
('global','simple','es','',1759937441,1759937441,2,2),
('global','simple','fr','',1759937441,1759937441,2,2),
('global','simple','hu','',1759937441,1759937441,2,2),
('global','simple','it','',1759937441,1759937441,2,2),
('global','simple','ja','',1759937441,1759937441,2,2),
('global','simple','nl','',1759937441,1759937441,2,2),
('global','simple','pl','',1759937441,1759937441,2,2),
('global','simple','pt','',1759937441,1759937441,2,2),
('global','simple','ru','',1759937441,1759937441,2,2),
('global','simple','sk','',1759937441,1759937441,2,2),
('global','simple','sv','',1759937441,1759937441,2,2),
('global','simple','th','',1759937441,1759937441,2,2),
('global','simple','tr','',1759937441,1759937441,2,2),
('global','simple','uk','',1759937441,1759937441,2,2),
('global','simple','zh_Hans','',1759937441,1759937441,2,2),
('gr','simple','ca','gr',1759940982,1759940982,2,2),
('gr','simple','cs','gr',1759940982,1759940982,2,2),
('gr','simple','de','gr',1759940982,1759940982,2,2),
('gr','simple','en','gr',1759940982,1759940982,2,2),
('gr','simple','es','gr',1759940982,1759940982,2,2),
('gr','simple','fr','gr',1759940982,1759940982,2,2),
('gr','simple','hu','gr',1759940982,1759940982,2,2),
('gr','simple','it','gr',1759940982,1759940982,2,2),
('gr','simple','ja','gr',1759940982,1759940982,2,2),
('gr','simple','nl','gr',1759940982,1759940982,2,2),
('gr','simple','pl','gr',1759940982,1759940982,2,2),
('gr','simple','pt','gr',1759940982,1759940982,2,2),
('gr','simple','ru','gr',1759940982,1759940982,2,2),
('gr','simple','sk','gr',1759940982,1759940982,2,2),
('gr','simple','sv','gr',1759940982,1759940982,2,2),
('gr','simple','th','gr',1759940982,1759940982,2,2),
('gr','simple','tr','gr',1759940982,1759940982,2,2),
('gr','simple','uk','gr',1759940982,1759940982,2,2),
('gr','simple','zh_Hans','gr',1759940982,1759940982,2,2),
('ignoreCase','simple','ca','',1759937441,1759937441,2,2),
('ignoreCase','simple','cs','',1759937441,1759937441,2,2),
('ignoreCase','simple','de','',1759937441,1759937441,2,2),
('ignoreCase','simple','en','',1759937441,1759937441,2,2),
('ignoreCase','simple','es','',1759937441,1759937441,2,2),
('ignoreCase','simple','fr','',1759937441,1759937441,2,2),
('ignoreCase','simple','hu','',1759937441,1759937441,2,2),
('ignoreCase','simple','it','',1759937441,1759937441,2,2),
('ignoreCase','simple','ja','',1759937441,1759937441,2,2),
('ignoreCase','simple','nl','',1759937441,1759937441,2,2),
('ignoreCase','simple','pl','',1759937441,1759937441,2,2),
('ignoreCase','simple','pt','',1759937441,1759937441,2,2),
('ignoreCase','simple','ru','',1759937441,1759937441,2,2),
('ignoreCase','simple','sk','',1759937441,1759937441,2,2),
('ignoreCase','simple','sv','',1759937441,1759937441,2,2),
('ignoreCase','simple','th','',1759937441,1759937441,2,2),
('ignoreCase','simple','tr','',1759937441,1759937441,2,2),
('ignoreCase','simple','uk','',1759937441,1759937441,2,2),
('ignoreCase','simple','zh_Hans','',1759937441,1759937441,2,2),
('kg','simple','ca','kg',1759941005,1759941005,2,2),
('kg','simple','cs','kg',1759941005,1759941005,2,2),
('kg','simple','de','kg',1759941005,1759941005,2,2),
('kg','simple','en','kg',1759941005,1759941005,2,2),
('kg','simple','es','kg',1759941005,1759941005,2,2),
('kg','simple','fr','kg',1759941005,1759941005,2,2),
('kg','simple','hu','kg',1759941005,1759941005,2,2),
('kg','simple','it','kg',1759941005,1759941005,2,2),
('kg','simple','ja','kg',1759941005,1759941005,2,2),
('kg','simple','nl','kg',1759941005,1759941005,2,2),
('kg','simple','pl','kg',1759941005,1759941005,2,2),
('kg','simple','pt','kg',1759941005,1759941005,2,2),
('kg','simple','ru','kg',1759941005,1759941005,2,2),
('kg','simple','sk','kg',1759941005,1759941005,2,2),
('kg','simple','sv','kg',1759941005,1759941005,2,2),
('kg','simple','th','kg',1759941005,1759941005,2,2),
('kg','simple','tr','kg',1759941005,1759941005,2,2),
('kg','simple','uk','kg',1759941005,1759941005,2,2),
('kg','simple','zh_Hans','kg',1759941005,1759941005,2,2),
('login','simple','de','',1759936899,1759936902,0,0),
('login','simple','en','',1759936899,1759936902,0,0),
('login','simple','fr','',1759936899,1759936902,0,0),
('login','simple','it','',1759936899,1759936902,0,0),
('multiline','simple','ca','',1759937441,1759937441,2,2),
('multiline','simple','cs','',1759937441,1759937441,2,2),
('multiline','simple','de','',1759937441,1759937441,2,2),
('multiline','simple','en','',1759937441,1759937441,2,2),
('multiline','simple','es','',1759937441,1759937441,2,2),
('multiline','simple','fr','',1759937441,1759937441,2,2),
('multiline','simple','hu','',1759937441,1759937441,2,2),
('multiline','simple','it','',1759937441,1759937441,2,2),
('multiline','simple','ja','',1759937441,1759937441,2,2),
('multiline','simple','nl','',1759937441,1759937441,2,2),
('multiline','simple','pl','',1759937441,1759937441,2,2),
('multiline','simple','pt','',1759937441,1759937441,2,2),
('multiline','simple','ru','',1759937441,1759937441,2,2),
('multiline','simple','sk','',1759937441,1759937441,2,2),
('multiline','simple','sv','',1759937441,1759937441,2,2),
('multiline','simple','th','',1759937441,1759937441,2,2),
('multiline','simple','tr','',1759937441,1759937441,2,2),
('multiline','simple','uk','',1759937441,1759937441,2,2),
('multiline','simple','zh_Hans','',1759937441,1759937441,2,2),
('object_add_dialog_custom_text.Brand','simple','ca','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','cs','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','de','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','en','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','es','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','fr','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','hu','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','it','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','ja','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','nl','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','pl','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','pt','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','ru','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','sk','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','sv','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','th','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','tr','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','uk','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Brand','simple','zh_Hans','',1759937981,1759937981,2,2),
('object_add_dialog_custom_text.Product','simple','ca','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','cs','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','de','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','en','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','es','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','fr','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','hu','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','it','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','ja','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','nl','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','pl','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','pt','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','ru','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','sk','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','sv','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','th','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','tr','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','uk','',1759941349,1759941349,2,2),
('object_add_dialog_custom_text.Product','simple','zh_Hans','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Brand','simple','ca','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','cs','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','de','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','en','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','es','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','fr','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','hu','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','it','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','ja','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','nl','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','pl','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','pt','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','ru','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','sk','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','sv','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','th','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','tr','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','uk','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Brand','simple','zh_Hans','',1759937981,1759937981,2,2),
('object_add_dialog_custom_title.Product','simple','ca','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','cs','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','de','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','en','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','es','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','fr','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','hu','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','it','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','ja','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','nl','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','pl','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','pt','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','ru','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','sk','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','sv','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','th','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','tr','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','uk','',1759941349,1759941349,2,2),
('object_add_dialog_custom_title.Product','simple','zh_Hans','',1759941349,1759941349,2,2),
('quantityValueRange','simple','ca','',1759950419,1759950419,2,2),
('quantityValueRange','simple','cs','',1759950419,1759950419,2,2),
('quantityValueRange','simple','de','',1759950419,1759950419,2,2),
('quantityValueRange','simple','en','',1759950419,1759950419,2,2),
('quantityValueRange','simple','es','',1759950419,1759950419,2,2),
('quantityValueRange','simple','fr','',1759950419,1759950419,2,2),
('quantityValueRange','simple','hu','',1759950419,1759950419,2,2),
('quantityValueRange','simple','it','',1759950419,1759950419,2,2),
('quantityValueRange','simple','ja','',1759950419,1759950419,2,2),
('quantityValueRange','simple','nl','',1759950419,1759950419,2,2),
('quantityValueRange','simple','pl','',1759950419,1759950419,2,2),
('quantityValueRange','simple','pt','',1759950419,1759950419,2,2),
('quantityValueRange','simple','ru','',1759950419,1759950419,2,2),
('quantityValueRange','simple','sk','',1759950419,1759950419,2,2),
('quantityValueRange','simple','sv','',1759950419,1759950419,2,2),
('quantityValueRange','simple','th','',1759950419,1759950419,2,2),
('quantityValueRange','simple','tr','',1759950419,1759950419,2,2),
('quantityValueRange','simple','uk','',1759950419,1759950419,2,2),
('quantityValueRange','simple','zh_Hans','',1759950419,1759950419,2,2),
('sticky','simple','ca','',1759937441,1759937441,2,2),
('sticky','simple','cs','',1759937441,1759937441,2,2),
('sticky','simple','de','',1759937441,1759937441,2,2),
('sticky','simple','en','',1759937441,1759937441,2,2),
('sticky','simple','es','',1759937441,1759937441,2,2),
('sticky','simple','fr','',1759937441,1759937441,2,2),
('sticky','simple','hu','',1759937441,1759937441,2,2),
('sticky','simple','it','',1759937441,1759937441,2,2),
('sticky','simple','ja','',1759937441,1759937441,2,2),
('sticky','simple','nl','',1759937441,1759937441,2,2),
('sticky','simple','pl','',1759937441,1759937441,2,2),
('sticky','simple','pt','',1759937441,1759937441,2,2),
('sticky','simple','ru','',1759937441,1759937441,2,2),
('sticky','simple','sk','',1759937441,1759937441,2,2),
('sticky','simple','sv','',1759937441,1759937441,2,2),
('sticky','simple','th','',1759937441,1759937441,2,2),
('sticky','simple','tr','',1759937441,1759937441,2,2),
('sticky','simple','uk','',1759937441,1759937441,2,2),
('sticky','simple','zh_Hans','',1759937441,1759937441,2,2),
('ton','simple','ca','ton',1759941021,1759941021,2,2),
('ton','simple','cs','ton',1759941021,1759941021,2,2),
('ton','simple','de','ton',1759941021,1759941021,2,2),
('ton','simple','en','ton',1759941021,1759941021,2,2),
('ton','simple','es','ton',1759941021,1759941021,2,2),
('ton','simple','fr','ton',1759941021,1759941021,2,2),
('ton','simple','hu','ton',1759941021,1759941021,2,2),
('ton','simple','it','ton',1759941021,1759941021,2,2),
('ton','simple','ja','ton',1759941021,1759941021,2,2),
('ton','simple','nl','ton',1759941021,1759941021,2,2),
('ton','simple','pl','ton',1759941021,1759941021,2,2),
('ton','simple','pt','ton',1759941021,1759941021,2,2),
('ton','simple','ru','ton',1759941021,1759941021,2,2),
('ton','simple','sk','ton',1759941021,1759941021,2,2),
('ton','simple','sv','ton',1759941021,1759941021,2,2),
('ton','simple','th','ton',1759941021,1759941021,2,2),
('ton','simple','tr','ton',1759941021,1759941021,2,2),
('ton','simple','uk','ton',1759941021,1759941021,2,2),
('ton','simple','zh_Hans','ton',1759941021,1759941021,2,2),
('unicode','simple','ca','',1759937441,1759937441,2,2),
('unicode','simple','cs','',1759937441,1759937441,2,2),
('unicode','simple','de','',1759937441,1759937441,2,2),
('unicode','simple','en','',1759937441,1759937441,2,2),
('unicode','simple','es','',1759937441,1759937441,2,2),
('unicode','simple','fr','',1759937441,1759937441,2,2),
('unicode','simple','hu','',1759937441,1759937441,2,2),
('unicode','simple','it','',1759937441,1759937441,2,2),
('unicode','simple','ja','',1759937441,1759937441,2,2),
('unicode','simple','nl','',1759937441,1759937441,2,2),
('unicode','simple','pl','',1759937441,1759937441,2,2),
('unicode','simple','pt','',1759937441,1759937441,2,2),
('unicode','simple','ru','',1759937441,1759937441,2,2),
('unicode','simple','sk','',1759937441,1759937441,2,2),
('unicode','simple','sv','',1759937441,1759937441,2,2),
('unicode','simple','th','',1759937441,1759937441,2,2),
('unicode','simple','tr','',1759937441,1759937441,2,2),
('unicode','simple','uk','',1759937441,1759937441,2,2),
('unicode','simple','zh_Hans','',1759937441,1759937441,2,2),
('up','simple','ca','',1759939307,1759939307,2,2),
('up','simple','cs','',1759939307,1759939307,2,2),
('up','simple','de','',1759939307,1759939307,2,2),
('up','simple','en','',1759939307,1759939307,2,2),
('up','simple','es','',1759939307,1759939307,2,2),
('up','simple','fr','',1759939307,1759939307,2,2),
('up','simple','hu','',1759939307,1759939307,2,2),
('up','simple','it','',1759939307,1759939307,2,2),
('up','simple','ja','',1759939307,1759939307,2,2),
('up','simple','nl','',1759939307,1759939307,2,2),
('up','simple','pl','',1759939307,1759939307,2,2),
('up','simple','pt','',1759939307,1759939307,2,2),
('up','simple','ru','',1759939307,1759939307,2,2),
('up','simple','sk','',1759939307,1759939307,2,2),
('up','simple','sv','',1759939307,1759939307,2,2),
('up','simple','th','',1759939307,1759939307,2,2),
('up','simple','tr','',1759939307,1759939307,2,2),
('up','simple','uk','',1759939307,1759939307,2,2),
('up','simple','zh_Hans','',1759939307,1759939307,2,2),
('warehouseAvailability','simple','ca','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','cs','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','de','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','en','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','es','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','fr','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','hu','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','it','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','ja','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','nl','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','pl','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','pt','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','ru','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','sk','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','sv','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','th','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','tr','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','uk','',1759949789,1759949789,2,2),
('warehouseAvailability','simple','zh_Hans','',1759949789,1759949789,2,2);
/*!40000 ALTER TABLE `translations_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations_messages`
--

DROP TABLE IF EXISTS `translations_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `translations_messages` (
  `key` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `type` varchar(10) DEFAULT NULL,
  `language` varchar(10) NOT NULL DEFAULT '',
  `text` text DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`key`,`language`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations_messages`
--

LOCK TABLES `translations_messages` WRITE;
/*!40000 ALTER TABLE `translations_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `translations_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tree_locks`
--

DROP TABLE IF EXISTS `tree_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tree_locks` (
  `id` int(11) NOT NULL DEFAULT 0,
  `type` enum('asset','document','object') NOT NULL DEFAULT 'asset',
  `locked` enum('self','propagate') DEFAULT NULL,
  PRIMARY KEY (`id`,`type`),
  KEY `type` (`type`),
  KEY `locked` (`locked`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tree_locks`
--

LOCK TABLES `tree_locks` WRITE;
/*!40000 ALTER TABLE `tree_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tree_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned DEFAULT NULL,
  `type` enum('user','userfolder','role','rolefolder') NOT NULL DEFAULT 'user',
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(190) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `language` varchar(10) DEFAULT 'en',
  `datetimeLocale` varchar(10) DEFAULT '',
  `contentLanguages` longtext DEFAULT NULL,
  `admin` tinyint(1) unsigned DEFAULT 0,
  `active` tinyint(1) unsigned DEFAULT 1,
  `permissions` text DEFAULT NULL,
  `roles` varchar(1000) DEFAULT NULL,
  `welcomescreen` tinyint(1) DEFAULT NULL,
  `closeWarning` tinyint(1) DEFAULT NULL,
  `memorizeTabs` tinyint(1) DEFAULT NULL,
  `allowDirtyClose` tinyint(1) unsigned DEFAULT 1,
  `docTypes` text DEFAULT NULL,
  `classes` text DEFAULT NULL,
  `twoFactorAuthentication` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `activePerspective` varchar(255) DEFAULT NULL,
  `perspectives` longtext DEFAULT NULL,
  `websiteTranslationLanguagesEdit` longtext DEFAULT NULL,
  `websiteTranslationLanguagesView` longtext DEFAULT NULL,
  `lastLogin` int(11) unsigned DEFAULT NULL,
  `keyBindings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`keyBindings`)),
  `passwordRecoveryToken` varchar(290) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_name` (`type`,`name`),
  KEY `parentId` (`parentId`),
  KEY `name` (`name`),
  KEY `password` (`password`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(0,0,'user','system',NULL,NULL,NULL,NULL,'en','',NULL,1,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(2,0,'user','admin','$2y$10$wefF6T686ZPLTeTEzp2PF.X/5FcLtaIjd0HVCf9ThNFla2PtuYa52',NULL,NULL,NULL,'en','',NULL,1,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_permission_definitions`
--

DROP TABLE IF EXISTS `users_permission_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_permission_definitions` (
  `key` varchar(50) NOT NULL DEFAULT '',
  `category` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_permission_definitions`
--

LOCK TABLES `users_permission_definitions` WRITE;
/*!40000 ALTER TABLE `users_permission_definitions` DISABLE KEYS */;
INSERT INTO `users_permission_definitions` VALUES
('assets',''),
('asset_metadata',''),
('classes',''),
('classificationstore',''),
('clear_cache',''),
('clear_fullpage_cache',''),
('clear_temp_files',''),
('dashboards',''),
('documents',''),
('document_types',''),
('emails',''),
('fieldcollections',''),
('notes_events',''),
('notifications',''),
('notifications_send',''),
('objectbricks',''),
('objects',''),
('objects_sort_method',''),
('predefined_properties',''),
('quantityValueUnits',''),
('recyclebin',''),
('redirects',''),
('seemode',''),
('selectoptions',''),
('share_configurations',''),
('sites',''),
('system_settings',''),
('tags_assignment',''),
('tags_configuration',''),
('tags_search',''),
('thumbnails',''),
('translations',''),
('users',''),
('website_settings',''),
('workflow_details','');
/*!40000 ALTER TABLE `users_permission_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_asset`
--

DROP TABLE IF EXISTS `users_workspaces_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_workspaces_asset` (
  `cid` int(11) unsigned NOT NULL DEFAULT 0,
  `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `userId` int(11) unsigned NOT NULL DEFAULT 0,
  `list` tinyint(1) DEFAULT 0,
  `view` tinyint(1) DEFAULT 0,
  `publish` tinyint(1) DEFAULT 0,
  `delete` tinyint(1) DEFAULT 0,
  `rename` tinyint(1) DEFAULT 0,
  `create` tinyint(1) DEFAULT 0,
  `settings` tinyint(1) DEFAULT 0,
  `versions` tinyint(1) DEFAULT 0,
  `properties` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`cid`,`userId`),
  UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
  UNIQUE KEY `idx_users_workspaces_list_permission` (`userId`,`cpath`,`list`),
  KEY `userId` (`userId`),
  CONSTRAINT `fk_users_workspaces_asset_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_workspaces_asset_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_asset`
--

LOCK TABLES `users_workspaces_asset` WRITE;
/*!40000 ALTER TABLE `users_workspaces_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_document`
--

DROP TABLE IF EXISTS `users_workspaces_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_workspaces_document` (
  `cid` int(11) unsigned NOT NULL DEFAULT 0,
  `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `userId` int(11) unsigned NOT NULL DEFAULT 0,
  `list` tinyint(1) unsigned DEFAULT 0,
  `view` tinyint(1) unsigned DEFAULT 0,
  `save` tinyint(1) unsigned DEFAULT 0,
  `publish` tinyint(1) unsigned DEFAULT 0,
  `unpublish` tinyint(1) unsigned DEFAULT 0,
  `delete` tinyint(1) unsigned DEFAULT 0,
  `rename` tinyint(1) unsigned DEFAULT 0,
  `create` tinyint(1) unsigned DEFAULT 0,
  `settings` tinyint(1) unsigned DEFAULT 0,
  `versions` tinyint(1) unsigned DEFAULT 0,
  `properties` tinyint(1) unsigned DEFAULT 0,
  PRIMARY KEY (`cid`,`userId`),
  UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
  UNIQUE KEY `idx_users_workspaces_list_permission` (`userId`,`cpath`,`list`),
  KEY `userId` (`userId`),
  CONSTRAINT `fk_users_workspaces_document_documents` FOREIGN KEY (`cid`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_workspaces_document_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_document`
--

LOCK TABLES `users_workspaces_document` WRITE;
/*!40000 ALTER TABLE `users_workspaces_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_object`
--

DROP TABLE IF EXISTS `users_workspaces_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_workspaces_object` (
  `cid` int(11) unsigned NOT NULL DEFAULT 0,
  `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `userId` int(11) unsigned NOT NULL DEFAULT 0,
  `list` tinyint(1) unsigned DEFAULT 0,
  `view` tinyint(1) unsigned DEFAULT 0,
  `save` tinyint(1) unsigned DEFAULT 0,
  `publish` tinyint(1) unsigned DEFAULT 0,
  `unpublish` tinyint(1) unsigned DEFAULT 0,
  `delete` tinyint(1) unsigned DEFAULT 0,
  `rename` tinyint(1) unsigned DEFAULT 0,
  `create` tinyint(1) unsigned DEFAULT 0,
  `settings` tinyint(1) unsigned DEFAULT 0,
  `versions` tinyint(1) unsigned DEFAULT 0,
  `properties` tinyint(1) unsigned DEFAULT 0,
  `lEdit` text DEFAULT NULL,
  `lView` text DEFAULT NULL,
  `layouts` text DEFAULT NULL,
  PRIMARY KEY (`cid`,`userId`),
  UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
  UNIQUE KEY `idx_users_workspaces_list_permission` (`userId`,`cpath`,`list`),
  KEY `userId` (`userId`),
  CONSTRAINT `fk_users_workspaces_object_objects` FOREIGN KEY (`cid`) REFERENCES `objects` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_workspaces_object_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_object`
--

LOCK TABLES `users_workspaces_object` WRITE;
/*!40000 ALTER TABLE `users_workspaces_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `versions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) unsigned DEFAULT NULL,
  `ctype` enum('document','asset','object') DEFAULT NULL,
  `userId` int(11) unsigned DEFAULT NULL,
  `note` text DEFAULT NULL,
  `stackTrace` text DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `public` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `serialized` tinyint(1) unsigned DEFAULT 0,
  `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
  `binaryFileHash` varchar(128) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `binaryFileId` bigint(20) unsigned DEFAULT NULL,
  `autoSave` tinyint(4) NOT NULL DEFAULT 0,
  `storageType` varchar(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`),
  KEY `ctype_cid` (`ctype`,`cid`),
  KEY `date` (`date`),
  KEY `public` (`public`),
  KEY `binaryFileHash` (`binaryFileHash`),
  KEY `autoSave` (`autoSave`),
  KEY `stackTrace` (`stackTrace`(1)),
  KEY `versionCount` (`versionCount`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
INSERT INTO `versions` VALUES
(1,2,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1759949761,0,1,1,NULL,NULL,0,'fs'),
(2,2,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1423): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#4 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#5 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#6 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#7 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#8 /var/www/html/public/index.php(19): require_once(\'...\')\n#9 {main}',1759949784,0,1,2,NULL,NULL,1,'fs');
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webdav_locks`
--

DROP TABLE IF EXISTS `webdav_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webdav_locks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` varchar(100) DEFAULT NULL,
  `timeout` int(10) unsigned DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `token` varbinary(100) DEFAULT NULL,
  `scope` tinyint(4) DEFAULT NULL,
  `depth` tinyint(4) DEFAULT NULL,
  `uri` varbinary(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `token` (`token`),
  KEY `uri` (`uri`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webdav_locks`
--

LOCK TABLES `webdav_locks` WRITE;
/*!40000 ALTER TABLE `webdav_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webdav_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_settings`
--

DROP TABLE IF EXISTS `website_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `website_settings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL DEFAULT '',
  `type` enum('text','document','asset','object','bool') DEFAULT NULL,
  `data` text DEFAULT NULL,
  `language` varchar(15) NOT NULL DEFAULT '',
  `siteId` int(11) unsigned DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `siteId` (`siteId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_settings`
--

LOCK TABLES `website_settings` WRITE;
/*!40000 ALTER TABLE `website_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `website_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `object_brand`
--

/*!50001 DROP VIEW IF EXISTS `object_brand`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_brand` AS select `object_query_brand`.`oo_id` AS `oo_id`,`object_query_brand`.`oo_classId` AS `oo_classId`,`object_query_brand`.`oo_className` AS `oo_className`,`object_query_brand`.`products` AS `products`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount` from (`object_query_brand` join `objects` on(`objects`.`id` = `object_query_brand`.`oo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_collection`
--

/*!50001 DROP VIEW IF EXISTS `object_collection`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_collection` AS select `object_query_collection`.`oo_id` AS `oo_id`,`object_query_collection`.`oo_classId` AS `oo_classId`,`object_query_collection`.`oo_className` AS `oo_className`,`object_query_collection`.`name` AS `name`,`object_query_collection`.`validity__start_date` AS `validity__start_date`,`object_query_collection`.`validity__end_date` AS `validity__end_date`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount` from (`object_query_collection` join `objects` on(`objects`.`id` = `object_query_collection`.`oo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_brand_de`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_brand_de`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_brand_de` AS select `object_query_brand`.`oo_id` AS `oo_id`,`object_query_brand`.`oo_classId` AS `oo_classId`,`object_query_brand`.`oo_className` AS `oo_className`,`object_query_brand`.`products` AS `products`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`de`.`ooo_id` AS `ooo_id`,`de`.`language` AS `language`,`de`.`brandName` AS `brandName` from ((`object_query_brand` join `objects` on(`objects`.`id` = `object_query_brand`.`oo_id`)) left join `object_localized_query_brand_de` `de` on(1 and `object_query_brand`.`oo_id` = `de`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_brand_en`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_brand_en`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_brand_en` AS select `object_query_brand`.`oo_id` AS `oo_id`,`object_query_brand`.`oo_classId` AS `oo_classId`,`object_query_brand`.`oo_className` AS `oo_className`,`object_query_brand`.`products` AS `products`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`en`.`ooo_id` AS `ooo_id`,`en`.`language` AS `language`,`en`.`brandName` AS `brandName` from ((`object_query_brand` join `objects` on(`objects`.`id` = `object_query_brand`.`oo_id`)) left join `object_localized_query_brand_en` `en` on(1 and `object_query_brand`.`oo_id` = `en`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_brand_fr`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_brand_fr`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_brand_fr` AS select `object_query_brand`.`oo_id` AS `oo_id`,`object_query_brand`.`oo_classId` AS `oo_classId`,`object_query_brand`.`oo_className` AS `oo_className`,`object_query_brand`.`products` AS `products`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`fr`.`ooo_id` AS `ooo_id`,`fr`.`language` AS `language`,`fr`.`brandName` AS `brandName` from ((`object_query_brand` join `objects` on(`objects`.`id` = `object_query_brand`.`oo_id`)) left join `object_localized_query_brand_fr` `fr` on(1 and `object_query_brand`.`oo_id` = `fr`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_product_de`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_product_de`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_product_de` AS select `object_query_product`.`oo_id` AS `oo_id`,`object_query_product`.`oo_classId` AS `oo_classId`,`object_query_product`.`oo_className` AS `oo_className`,`object_query_product`.`sku` AS `sku`,`object_query_product`.`brand__id` AS `brand__id`,`object_query_product`.`brand__type` AS `brand__type`,`object_query_product`.`Color` AS `Color`,`object_query_product`.`mainImage` AS `mainImage`,`object_query_product`.`gallery__images` AS `gallery__images`,`object_query_product`.`gallery__hotspots` AS `gallery__hotspots`,`object_query_product`.`collections` AS `collections`,`object_query_product`.`files` AS `files`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`de`.`ooo_id` AS `ooo_id`,`de`.`language` AS `language`,`de`.`name` AS `name`,`de`.`description` AS `description` from ((`object_query_product` join `objects` on(`objects`.`id` = `object_query_product`.`oo_id`)) left join `object_localized_query_product_de` `de` on(1 and `object_query_product`.`oo_id` = `de`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_product_en`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_product_en`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_product_en` AS select `object_query_product`.`oo_id` AS `oo_id`,`object_query_product`.`oo_classId` AS `oo_classId`,`object_query_product`.`oo_className` AS `oo_className`,`object_query_product`.`sku` AS `sku`,`object_query_product`.`brand__id` AS `brand__id`,`object_query_product`.`brand__type` AS `brand__type`,`object_query_product`.`Color` AS `Color`,`object_query_product`.`mainImage` AS `mainImage`,`object_query_product`.`gallery__images` AS `gallery__images`,`object_query_product`.`gallery__hotspots` AS `gallery__hotspots`,`object_query_product`.`collections` AS `collections`,`object_query_product`.`files` AS `files`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`en`.`ooo_id` AS `ooo_id`,`en`.`language` AS `language`,`en`.`name` AS `name`,`en`.`description` AS `description` from ((`object_query_product` join `objects` on(`objects`.`id` = `object_query_product`.`oo_id`)) left join `object_localized_query_product_en` `en` on(1 and `object_query_product`.`oo_id` = `en`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_product_fr`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_product_fr`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_product_fr` AS select `object_query_product`.`oo_id` AS `oo_id`,`object_query_product`.`oo_classId` AS `oo_classId`,`object_query_product`.`oo_className` AS `oo_className`,`object_query_product`.`sku` AS `sku`,`object_query_product`.`brand__id` AS `brand__id`,`object_query_product`.`brand__type` AS `brand__type`,`object_query_product`.`Color` AS `Color`,`object_query_product`.`mainImage` AS `mainImage`,`object_query_product`.`gallery__images` AS `gallery__images`,`object_query_product`.`gallery__hotspots` AS `gallery__hotspots`,`object_query_product`.`collections` AS `collections`,`object_query_product`.`files` AS `files`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`fr`.`ooo_id` AS `ooo_id`,`fr`.`language` AS `language`,`fr`.`name` AS `name`,`fr`.`description` AS `description` from ((`object_query_product` join `objects` on(`objects`.`id` = `object_query_product`.`oo_id`)) left join `object_localized_query_product_fr` `fr` on(1 and `object_query_product`.`oo_id` = `fr`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_product`
--

/*!50001 DROP VIEW IF EXISTS `object_product`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_product` AS select `object_query_product`.`oo_id` AS `oo_id`,`object_query_product`.`oo_classId` AS `oo_classId`,`object_query_product`.`oo_className` AS `oo_className`,`object_query_product`.`sku` AS `sku`,`object_query_product`.`brand__id` AS `brand__id`,`object_query_product`.`brand__type` AS `brand__type`,`object_query_product`.`Color` AS `Color`,`object_query_product`.`mainImage` AS `mainImage`,`object_query_product`.`gallery__images` AS `gallery__images`,`object_query_product`.`gallery__hotspots` AS `gallery__hotspots`,`object_query_product`.`collections` AS `collections`,`object_query_product`.`files` AS `files`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount` from (`object_query_product` join `objects` on(`objects`.`id` = `object_query_product`.`oo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_warehouse`
--

/*!50001 DROP VIEW IF EXISTS `object_warehouse`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_warehouse` AS select `object_query_warehouse`.`oo_id` AS `oo_id`,`object_query_warehouse`.`oo_classId` AS `oo_classId`,`object_query_warehouse`.`oo_className` AS `oo_className`,`object_query_warehouse`.`name` AS `name`,`object_query_warehouse`.`location__longitude` AS `location__longitude`,`object_query_warehouse`.`location__latitude` AS `location__latitude`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount` from (`object_query_warehouse` join `objects` on(`objects`.`id` = `object_query_warehouse`.`oo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-08 21:29:40
